"""Read-only validation of the saved DOCX against native Zotero exports."""
import hashlib
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from lxml import etree as ET

ROOT = Path(__file__).resolve().parents[1]
DOCX = ROOT / (sys.argv[1] if len(sys.argv) > 1 else "outputs/NHIS_Manuscript.docx")
LITERATURE = ROOT / "outputs/literature"
native = json.loads((LITERATURE / "zotero_manuscript_citations.json").read_text(encoding="utf-8-sig"))
imported = json.loads((LITERATURE / "zotero_items.json").read_text(encoding="utf-8-sig"))
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
q = lambda local: "{" + W + "}" + local
normalize = lambda text: re.sub(r"\s+", " ", text).strip()

with zipfile.ZipFile(DOCX) as archive:
    doc = ET.fromstring(archive.read("word/document.xml"))
    props = ET.fromstring(archive.read("docProps/custom.xml"))
    styles = ET.fromstring(archive.read("word/styles.xml"))
    media = [name for name in archive.namelist() if name.startswith("word/media/")]

fields = []
stack = []
paragraph_index = -1
for event, node in ET.iterwalk(doc, events=("start", "end")):
    if event == "start" and node.tag == q("p"):
        paragraph_index += 1
    if event != "end":
        continue
    if node.tag == q("fldChar"):
        kind = node.get(q("fldCharType"))
        if kind == "begin":
            stack.append({"code": "", "phase": "code", "text": "", "paragraphs": {}})
        elif kind == "separate":
            assert stack, "Unpaired field separator"
            stack[-1]["phase"] = "result"
        elif kind == "end":
            assert stack, "Unpaired field end"
            fields.append(stack.pop())
    elif node.tag == q("instrText") and stack:
        stack[-1]["code"] += node.text or ""
    elif node.tag == q("t") and stack and stack[-1]["phase"] == "result":
        field = stack[-1]
        field["text"] += node.text or ""
        field["paragraphs"][paragraph_index] = field["paragraphs"].get(paragraph_index, "") + (node.text or "")
assert not stack, "Unclosed complex field"

citations = [field for field in fields if "ZOTERO_ITEM CSL_CITATION" in field["code"]]
bibliographies = [field for field in fields if "ZOTERO_BIBL" in field["code"]]
assert len(citations) == len(native["citations"]) == 19
assert len(bibliographies) == 1
all_ids, all_uris = set(), set()
for actual, expected in zip(citations, native["citations"]):
    citation = json.loads(actual["code"].split("CSL_CITATION", 1)[1].strip())
    assert citation["citationID"] == expected["citationID"], "Citation ID/order changed"
    assert [str(item["id"]) for item in citation["citationItems"]] == [str(item["id"]) for item in expected["citation"]["citationItems"]]
    for item, expected_item in zip(citation["citationItems"], expected["citation"]["citationItems"]):
        assert set(expected_item["uris"]).issubset(item["uris"]), "Genuine item URI missing"
        assert item["itemData"]["title"] == expected_item["itemData"]["title"]
        all_ids.add(str(item["id"]))
        all_uris.update(item["uris"])
    assert normalize(actual["text"]) == normalize(expected["plainCitation"]), "Cached citation changed"
    assert normalize(citation["properties"]["plainCitation"]) == normalize(expected["plainCitation"])
assert len(all_ids) == len(all_uris) == 25
assert all_ids == {str(item["id"]) for item in imported["items"]}
assert all_uris == {item["uri"] for item in imported["items"]}

bibliography = bibliographies[0]
bibdata = json.loads(bibliography["code"].split("ZOTERO_BIBL", 1)[1].split("CSL_BIBLIOGRAPHY", 1)[0].strip())
assert bibdata == {"uncited": [], "omitted": [], "custom": []}
actual_entries = [text for text in bibliography["paragraphs"].values() if text.strip()]
assert len(actual_entries) == len(native["bibliography"]["entries"]) == 25
for actual, expected in zip(actual_entries, native["bibliography"]["entries"]):
    assert normalize(actual) == normalize(expected["text"]), "Bibliography text differs: " + actual[:90]

chunks = []
for prop in props:
    name = prop.get("name", "")
    if name.startswith("ZOTERO_PREF_"):
        chunks.append((int(name.rsplit("_", 1)[1]), "".join(prop.itertext())))
chunks.sort()
assert [index for index, _ in chunks] == list(range(1, len(chunks) + 1))
assert all(len(value.encode("utf-16-le")) // 2 <= 255 for _, value in chunks)
pref_xml = "".join(value for _, value in chunks)
preferences = ET.fromstring(pref_xml.encode())
style = preferences.find("style")
assert style.get("id") == native["style"]["id"]
assert style.get("locale") == "en-US"
assert style.get("hasBibliography") == "1"
assert style.get("bibliographyStyleHasBeenSet") == "1", "Saved document lacks first-refresh formatting flag"
pref_values = {pref.get("name"): pref.get("value") for pref in preferences.findall("prefs/pref")}
assert pref_values.get("fieldType") == "Field"
assert "\ufffd" not in "".join(doc.xpath(".//w:t/text()", namespaces=NS))
assert len(doc.findall(".//w:tbl", NS)) == 3
assert len(doc.findall(".//w:drawing", NS)) == 4

bib_style = styles.find("w:style[@w:styleId='Literaturverzeichnis']", NS)
spacing = bib_style.find("w:pPr/w:spacing", NS)
sha256 = hashlib.sha256(DOCX.read_bytes()).hexdigest()
report = f"""Zotero manuscript verification
Checked at: {datetime.now(timezone.utc).isoformat()}
Document: outputs/{DOCX.name}
SHA-256: {sha256}

Native Zotero processing
- Zotero version: {imported['zoteroVersion']}
- Project collection: {imported['collection']['name']}
- Actual library items imported and exported: 25.
- Style: {native['style']['id']}
- Processor: {native['style']['processor']}
- Native manuscript citation clusters: 19; unique cited references: 25.

Microsoft Word refresh
- The coordinating agent observed the Zotero Refresh command execute in Microsoft Word without an error.
- The coordinating agent saved the resulting document using Ctrl+S.
- This observation is reported from the coordinating agent; the validation script itself does not operate Word.
- Saved preference bibliographyStyleHasBeenSet is now 1 (it was false in the pre-Word export), consistent with Zotero applying bibliography formatting.

Independent read-only validation of the saved DOCX: PASSED
- All 19 complex CSL_CITATION fields remain present, balanced, and parseable.
- Citation IDs and document order match the pre-Word native citation export.
- Every cited item ID, genuine Zotero URI, and embedded title matches the native library export.
- There are exactly 25 distinct Zotero item IDs and 25 corresponding real item URIs.
- Every cached citation and all 25 bibliography entries match native Zotero output after whitespace normalization.
- One live ZOTERO_BIBL field remains, with no uncited, omitted, or custom references.
- ZOTERO_PREF chunks are sequential, no longer than 255 UTF-16 code units, and reassemble into valid preference XML.
- Style, en-US locale, bibliography flag, and Field integration type are retained.
- Three tables and four drawing objects remain present; no Unicode replacement characters occur in document text.
- Current Bibliography style spacing: line={spacing.get(q('line'))} twips-auto, after={spacing.get(q('after'))} twips.

Visual review performed on Word-exported page images 17-23 of the initial 23-page post-refresh render
- Pages 17-18: all four English figure legends are complete and readable.
- Page 19: shared methods/source statement is complete, with no clipping or overlap.
- Pages 20-23: figures 1-4 and their labels, numerical intervals, footnotes, and page numbers are visible and readable.
- No layout defect was detected on these seven pages.
- The coordinating agent separately identified a lone final reference on page 13 of the initial render. The current bibliography spacing is recorded above; a modified copy requires a fresh visual render.

Layout-copy record
{('The final copy was patched directly in OOXML: bibliography spacing after each entry was reduced to 6 pt while retaining 11 pt text and single spacing; Title, Subtitle, Heading 1, and Heading 2 now explicitly use Times New Roman without font-theme attributes; 19 ordinary spaces immediately before citation fields were changed to nonbreaking spaces. Zotero instructions were preserved byte-for-byte at the XML text level. All other ZIP parts were retained unchanged. The final copy requires a fresh Word render and visual review.' if DOCX.name.endswith('_Final.docx') else 'No layout-copy patch is recorded for this file.')}

Scope
This check verifies Zotero linkage, preserved native citation content, and the specified rendered pages. It is not an independent replication of the statistical analysis or source-level fact checking.
"""
(LITERATURE / "Zotero_verification.txt").write_text(report, encoding="utf-8")
(ROOT / "work/zotero_structural_check.json").write_text(json.dumps({
    "passed": True, "sha256": sha256, "citationClusters": len(citations),
    "uniqueCitedItems": len(all_ids), "bibliographyEntries": len(actual_entries),
    "preferenceChunks": len(chunks), "bibliographyStyleHasBeenSet": style.get("bibliographyStyleHasBeenSet"),
    "bibliographySpacingAfterTwips": spacing.get(q("after"))
}, indent=2), encoding="utf-8")
print(json.dumps({"passed": True, "citationClusters": len(citations), "references": len(actual_entries), "prefChunks": len(chunks), "sha256": sha256}))
