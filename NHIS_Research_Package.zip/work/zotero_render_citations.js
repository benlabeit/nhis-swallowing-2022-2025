/*
 * Run in Zotero > Tools > Developer > Run JavaScript, async enabled, after
 * zotero_import_export.js. Reads the ordered manuscript blocks and true Zotero
 * item mapping. This script does not change any library items or preferences.
 * It renders citations and bibliography with Zotero's installed CSL engine.
 * Word Refresh must still be verified on the final DOCX.
 */

const projectRoot = String.raw`C:\Users\benlabeit\Documents\Codex\2026-11-06\nhis-p1-analyse`;
const importPath = projectRoot + "\\outputs\\literature\\zotero_items.json";
const bodyPath = projectRoot + "\\work\\manuscript_body.json";
const outputPath = projectRoot + "\\outputs\\literature\\zotero_manuscript_citations.json";
const styleID = "http://www.zotero.org/styles/springer-vancouver-brackets";
const locale = "en-US";
const readJSON = async path => JSON.parse((await Zotero.File.getContentsAsync(path)).replace(/^\uFEFF/, ""));
const imported = await readJSON(importPath);
const blocks = await readJSON(bodyPath);
if (!Array.isArray(blocks) || !blocks.length || !Array.isArray(imported.items)) {
    throw new Error("Expected manuscript block array and native Zotero item export.");
}
if (imported.style.id !== styleID) throw new Error("Imported Zotero style does not match manuscript style.");
await Zotero.Styles.init();
const style = Zotero.Styles.get(styleID);
if (!style) throw new Error("Required installed Zotero style is unavailable: " + styleID);

const byRefID = new Map();
for (const record of imported.items) {
    if (byRefID.has(record.refID)) throw new Error("Duplicate exported reference ID: " + record.refID);
    const item = await Zotero.Items.getAsync(record.id);
    if (!item || item.deleted || item.key !== record.key || item.libraryID !== record.libraryID) {
        throw new Error("The exported Zotero item cannot be verified: " + record.refID);
    }
    await item.loadAllData();
    const marker = "NHIS reference ID: " + record.refID;
    if (!item.getField("extra").split(/\r?\n/).includes(marker)) {
        throw new Error("Missing project reference marker on actual Zotero item: " + record.refID);
    }
    byRefID.set(record.refID, { ...record, item, uri: Zotero.URI.getItemURI(item) });
}

const plans = [];
for (let blockIndex = 0; blockIndex < blocks.length; blockIndex++) {
    const block = blocks[blockIndex];
    if (!Array.isArray(block.refs)) throw new Error("Missing refs array at block " + blockIndex);
    if (!block.refs.length) continue;
    if (new Set(block.refs).size !== block.refs.length) {
        throw new Error("Repeated reference within one citation cluster at block " + blockIndex);
    }
    for (const refID of block.refs) {
        if (!byRefID.has(refID)) throw new Error("Unimported manuscript reference: " + refID);
    }
    plans.push({
        blockIndex,
        citationID: "NHISB" + String(blockIndex).padStart(4, "0"),
        refIDs: [...block.refs]
    });
}
if (!plans.length) throw new Error("The manuscript contains no citation clusters.");
const firstCitedRefIDs = [...new Set(plans.flatMap(plan => plan.refIDs))];
const itemIDToRefID = new Map([...byRefID.values()].map(record => [String(record.id), record.refID]));
const useRs = !!Zotero.Prefs.get("cite.useCiteprocRs");

function processorCitations() {
    return plans.map(plan => ({
        citationID: plan.citationID,
        citationItems: plan.refIDs.map(refID => ({ id: byRefID.get(refID).id })),
        properties: { noteIndex: 0 }
    }));
}

function render(format) {
    const engine = style.getCiteProc(locale, format, { automaticJournalAbbreviations: false });
    try {
        // citeproc-rs calls its unformatted mode "plain"; citeproc-js uses "text".
        const rebuildFormat = useRs && format === "text" ? "plain" : format;
        const rendered = engine.rebuildProcessorState(processorCitations(), rebuildFormat, []);
        const citationText = {};
        if (useRs) {
            for (const [citationID, text] of engine.getBatchedUpdates().clusters) {
                citationText[citationID] = text;
            }
        } else {
            for (const [citationID, noteIndex, text] of rendered) citationText[citationID] = text;
        }
        for (const plan of plans) {
            if (typeof citationText[plan.citationID] !== "string" || !citationText[plan.citationID]) {
                throw new Error("Native CSL processor did not render " + plan.citationID + " in " + format);
            }
        }
        const bibliography = engine.makeBibliography();
        if (!bibliography || bibliography[1].length !== firstCitedRefIDs.length) {
            throw new Error("Native bibliography count differs from unique cited references.");
        }
        return {
            citationText,
            bibliographyParameters: bibliography[0],
            bibliographyEntries: bibliography[1],
            bibliography: Zotero.Cite.makeFormattedBibliography(engine, format),
            itemData: Object.fromEntries(firstCitedRefIDs.map(refID => [
                refID, engine.sys.retrieveItem(byRefID.get(refID).id)
            ]))
        };
    } finally {
        engine.free();
    }
}

const textRender = render("text");
const rtfRender = render("rtf");
const htmlRender = render("html");
const citations = plans.map(plan => {
    const citation = {
        citationID: plan.citationID,
        properties: {
            formattedCitation: rtfRender.citationText[plan.citationID],
            plainCitation: textRender.citationText[plan.citationID],
            noteIndex: 0
        },
        citationItems: plan.refIDs.map(refID => {
            const record = byRefID.get(refID);
            return {
                id: record.id,
                uris: [record.uri],
                itemData: textRender.itemData[refID]
            };
        }),
        schema: "https://github.com/citation-style-language/schema/raw/master/csl-citation.json"
    };
    const serialized = JSON.stringify(citation);
    return {
        ...plan,
        plainCitation: textRender.citationText[plan.citationID],
        formattedCitation: rtfRender.citationText[plan.citationID],
        htmlCitation: htmlRender.citationText[plan.citationID],
        citation,
        serialized,
        fieldCode: " ADDIN ZOTERO_ITEM CSL_CITATION " + serialized + " "
    };
});

const bibliographyEntries = textRender.bibliographyEntries.map((text, index) => ({
    number: index + 1,
    itemIDs: textRender.bibliographyParameters.entry_ids[index].map(String),
    refIDs: textRender.bibliographyParameters.entry_ids[index].map(id => {
        const refID = itemIDToRefID.get(String(id));
        if (!refID) throw new Error("Unknown bibliography item from native engine: " + id);
        return refID;
    }),
    text: text.trim(),
    rtf: rtfRender.bibliographyEntries[index],
    html: htmlRender.bibliographyEntries[index]
}));
// Enforce that all formats use the same bibliography item order.
for (const renderResult of [rtfRender, htmlRender]) {
    if (JSON.stringify(renderResult.bibliographyParameters.entry_ids)
        !== JSON.stringify(textRender.bibliographyParameters.entry_ids)) {
        throw new Error("Native CSL bibliography ordering differs across output formats.");
    }
}

const documentData = new Zotero.Integration.DocumentData();
documentData.sessionID = imported.documentPreferences.sessionID || Zotero.Utilities.randomString(10);
documentData.style.styleID = styleID;
documentData.style.locale = locale;
documentData.style.hasBibliography = true;
documentData.style.bibliographyStyleHasBeenSet = false;
documentData.prefs.fieldType = "Field";
documentData.prefs.noteType = 0;
documentData.prefs.automaticJournalAbbreviations = false;
documentData.prefs.delayCitationUpdates = false;
const serializedPreferences = documentData.serialize();
const customProperties = [];
for (let start = 0; start < serializedPreferences.length; start += 255) {
    customProperties.push({
        name: "ZOTERO_PREF_" + (customProperties.length + 1),
        value: serializedPreferences.slice(start, start + 255)
    });
}
const bibliographyFieldData = { uncited: [], omitted: [], custom: [] };
const citationByBlock = new Map(citations.map(citation => [citation.blockIndex, citation]));
const result = {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    generator: "Zotero native CSL engine with actual project-library items",
    zoteroVersion: Zotero.version,
    sourceBodyFile: "work/manuscript_body.json",
    sourceItemFile: "outputs/literature/zotero_items.json",
    style: { id: styleID, title: style.title, locale, processor: useRs ? "citeproc-rs" : "citeproc-js" },
    firstCitedRefIDs,
    uncitedImportedRefIDs: [...byRefID.keys()].filter(refID => !firstCitedRefIDs.includes(refID)),
    citations,
    blocks: blocks.map((block, index) => ({
        ...block,
        blockIndex: index,
        citationID: citationByBlock.has(index) ? citationByBlock.get(index).citationID : null
    })),
    bibliography: {
        parameters: textRender.bibliographyParameters,
        entries: bibliographyEntries,
        text: textRender.bibliography,
        rtf: rtfRender.bibliography,
        html: htmlRender.bibliography,
        fieldData: bibliographyFieldData,
        fieldCode: " ADDIN ZOTERO_BIBL " + JSON.stringify(bibliographyFieldData) + " CSL_BIBLIOGRAPHY "
    },
    documentPreferences: {
        serialized: serializedPreferences,
        customProperties,
        style: documentData.style,
        prefs: documentData.prefs,
        sessionID: documentData.sessionID
    },
    verification: {
        genuineLibraryItemsVerified: true,
        nativeCitationProcessing: true,
        nativeBibliographyProcessing: true,
        citationClusters: citations.length,
        uniqueCitedReferences: firstCitedRefIDs.length,
        wordRefreshVerified: false
    }
};

await Zotero.File.putContentsAsync(outputPath, JSON.stringify(result, null, 2));
await Zotero.File.putContentsAsync(projectRoot + "\\outputs\\literature\\zotero_manuscript_bibliography.txt", result.bibliography.text);
return JSON.stringify({
    status: "Rendered manuscript citations and bibliography through Zotero",
    citationClusters: citations.length,
    uniqueCitedReferences: firstCitedRefIDs.length,
    uncitedImportedRefIDs: result.uncitedImportedRefIDs,
    output: outputPath,
    nextStep: "Build DOCX fields from fieldCode plus plainCitation, add customProperties, then verify Zotero Refresh in Word."
}, null, 2);
