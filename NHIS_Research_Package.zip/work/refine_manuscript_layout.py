"""Create a minimally patched OOXML copy, retaining every Zotero field."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as ET
import json

root = Path(__file__).resolve().parents[1]
source = root / "outputs/NHIS_Manuscript.docx"
target = root / "outputs/NHIS_Manuscript_Final.docx"
ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
q = lambda name: "{" + ns["w"] + "}" + name
with ZipFile(source) as archive:
    contents = {part.filename: archive.read(part.filename) for part in archive.infolist()}
    infos = archive.infolist()

styles = ET.fromstring(contents["word/styles.xml"])
changed_styles = []
for style in styles.findall("w:style", ns):
    name_node = style.find("w:name", ns)
    name = name_node.get(q("val"), "").lower() if name_node is not None else ""
    if name == "bibliography":
        spacing = style.find("w:pPr/w:spacing", ns)
        assert spacing is not None and spacing.get(q("line")) == "240"
        spacing.set(q("after"), "120")
    if name in {"title", "subtitle", "heading 1", "heading 2"}:
        rpr = style.find("w:rPr", ns)
        if rpr is None:
            rpr = ET.SubElement(style, q("rPr"))
        fonts = rpr.find("w:rFonts", ns)
        if fonts is None:
            fonts = ET.Element(q("rFonts"))
            rpr.insert(0, fonts)
        for attribute in list(fonts.attrib):
            if ET.QName(attribute).localname.lower().endswith("theme"):
                del fonts.attrib[attribute]
        for attribute in ("ascii", "hAnsi", "eastAsia", "cs"):
            fonts.set(q(attribute), "Times New Roman")
        changed_styles.append(name)
assert len(changed_styles) == 4

doc = ET.fromstring(contents["word/document.xml"])
original_instructions = doc.xpath(".//w:instrText/text()", namespaces=ns)
changed_spaces = 0
for paragraph in doc.findall(".//w:p", ns):
    children = list(paragraph)
    for index, child in enumerate(children):
        begin = child.find("w:fldChar", ns) if child.tag == q("r") else None
        if begin is None or begin.get(q("fldCharType")) != "begin":
            continue
        instruction = ""
        for following in children[index + 1:]:
            instruction += "".join(following.xpath(".//w:instrText/text()", namespaces=ns))
            separator = following.find("w:fldChar", ns)
            if separator is not None and separator.get(q("fldCharType")) == "separate":
                break
        if "ZOTERO_ITEM CSL_CITATION" not in instruction:
            continue
        previous_texts = [text_node for prior in children[:index] for text_node in prior.findall(".//w:t", ns) if text_node.text]
        assert previous_texts, "No preceding text for citation"
        last = previous_texts[-1]
        assert last.text.endswith(" "), "Citation does not have expected preceding ordinary space"
        last.text = last.text[:-1] + "\u00a0"
        changed_spaces += 1
assert changed_spaces == 19
assert original_instructions == doc.xpath(".//w:instrText/text()", namespaces=ns)

contents["word/styles.xml"] = ET.tostring(styles, xml_declaration=True, encoding="UTF-8", standalone=True)
contents["word/document.xml"] = ET.tostring(doc, xml_declaration=True, encoding="UTF-8", standalone=True)
with ZipFile(target, "w") as archive:
    for info in infos:
        archive.writestr(info, contents[info.filename])
summary = {
    "source": str(source), "target": str(target),
    "bibliographySpacingAfterPoints": 6,
    "headingFont": "Times New Roman", "changedStyles": changed_styles,
    "nonbreakingSpacesBeforeCitationFields": changed_spaces,
    "citationInstructionsUnchanged": True,
    "unchangedZipParts": len(infos) - 2
}
(root / "work/manuscript_layout_patch.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary))
