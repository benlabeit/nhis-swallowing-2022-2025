"""Build the manuscript only after the root agent has run the artifact marker.

Run with the bundled Python runtime and --approve-create. This script deliberately
does not launch Word, LibreOffice, or any renderer. Root performs visual QA.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from lxml import etree
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
AUTHORS = ["Cinja Huber", "Gero Lueg", "Anel Karisik", "Sriramya Lapa",
           "Anne Jung", "Orhan Aktas", "Michael Gliem", "Paul Muhle",
           "Sonja Suntrup-Krueger", "Rainer Dziewas", "Bendix Labeit"]
FIGURES = ["Figure_1_Prevalence.png", "Figure_2_Prevalence_differences.png",
           "Figure_3_Sensitivity.png", "Figure_4_Stroke_robustness.png"]
GROUPS = {"all": "All adults 65+", "stroke": "Stroke history", "no_stroke": "No stroke history"}
METHODS = {
    "main": "Direct age standardization",
    "age_sex_adjusted": "Age and sex adjustment",
    "self_direct_age_standardized": "Self-response only\nAge standardization",
    "self_age_sex_adjusted": "Self-response only\nAge and sex adjustment",
}
NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS_CP = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties"
NS_VT = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
NS_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
NS_CT = "http://schemas.openxmlformats.org/package/2006/content-types"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def read_tsv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def plain_heading(text):
    return re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 ]", " ", text)).strip()


def font(run, size=11, bold=False):
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)
    rpr = run._r.get_or_add_rPr()
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is not None:
        for name in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
            fonts.attrib.pop(qn("w:" + name), None)
        for name in ("ascii", "hAnsi", "eastAsia", "cs"):
            fonts.set(qn("w:" + name), "Times New Roman")


def configure(doc):
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(0.85)
    section.left_margin = section.right_margin = Inches(1)
    section.header_distance = section.footer_distance = Inches(0.4)
    for name in ("Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Caption"):
        st = doc.styles[name]
        st.font.name = "Times New Roman"
        st.font.color.rgb = RGBColor(0, 0, 0)
        st.font.size = Pt(11)
        st.font.underline = False
        st.paragraph_format.line_spacing = 1.5
        st.paragraph_format.space_after = Pt(6)
        st.paragraph_format.widow_control = True
        for border in list(st.element.findall(".//" + qn("w:pBdr"))):
            border.getparent().remove(border)
        rpr = st.element.get_or_add_rPr()
        color = rpr.find(qn("w:color"))
        if color is not None:
            for k in list(color.attrib):
                if k != qn("w:val"):
                    del color.attrib[k]
            color.set(qn("w:val"), "000000")
        lang = OxmlElement("w:lang")
        lang.set(qn("w:val"), "en-US")
        rpr.append(lang)
    doc.styles["Title"].font.size = Pt(16)
    doc.styles["Title"].font.bold = True
    doc.styles["Title"].paragraph_format.line_spacing = 1.15
    doc.styles["Title"].paragraph_format.keep_with_next = True
    doc.styles["Subtitle"].font.italic = False
    doc.styles["Subtitle"].paragraph_format.keep_with_next = True
    for name in ("Heading 1", "Heading 2"):
        doc.styles[name].font.bold = True
        doc.styles[name].paragraph_format.space_before = Pt(12)
        doc.styles[name].paragraph_format.space_after = Pt(6)
        doc.styles[name].paragraph_format.keep_with_next = True
    doc.core_properties.author = ", ".join(AUTHORS)
    doc.core_properties.last_modified_by = ""
    doc.core_properties.subject = "NHIS 2022 and 2025 swallowing difficulties among older adults"
    doc.core_properties.keywords = "NHIS; swallowing difficulties; older adults; stroke; survey analysis"
    # Keep the actual Zotero-generated cached results until the Zotero plugin refreshes them.
    update = doc.settings.element.find(qn("w:updateFields"))
    if update is None:
        update = OxmlElement("w:updateFields")
        doc.settings.element.append(update)
    update.set(qn("w:val"), "false")
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    begin_field(footer, " PAGE ")
    font(footer.add_run("1"), 10)
    end_field(footer)


def begin_field(paragraph, code):
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    begin.set(qn("w:dirty"), "false")
    paragraph.add_run()._r.append(begin)
    # A single instruction preserves Zotero JSON without accidental whitespace insertion.
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = code
    paragraph.add_run()._r.append(instr)
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    paragraph.add_run()._r.append(sep)


def end_field(paragraph):
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    paragraph.add_run()._r.append(end)


def add_citation(paragraph, citation):
    font(paragraph.add_run(" "))
    begin_field(paragraph, citation["fieldCode"])
    font(paragraph.add_run(citation["plainCitation"]))
    end_field(paragraph)


def page_heading(doc, text):
    p = doc.add_paragraph(plain_heading(text), "Heading 1")
    p.paragraph_format.page_break_before = True
    return p


def add_note(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_before = Pt(6)
    font(p.add_run(text), 10)
    return p


def author_material(source):
    by_name = {a["name"]: a for a in source["authors"]}
    # Optional separately verified additions may be supplied without altering the
    # faithful transcription of the previous manuscript.
    extra_path = ROOT / "work/author_information_additions.json"
    if extra_path.exists():
        additions = read_json(extra_path)
        for author in additions.get("authors", []):
            by_name[author["name"]] = author
        source["affiliations"].update(additions.get("affiliations", {}))
    ordered_ids = []
    for name in AUTHORS:
        for identifier in by_name.get(name, {}).get("source_affiliation_ids", []):
            if identifier not in ordered_ids:
                ordered_ids.append(identifier)
    numbers = {identifier: str(i + 1) for i, identifier in enumerate(ordered_ids)}
    missing_affiliation = [name for name in AUTHORS if not by_name.get(name, {}).get("source_affiliation_ids")]
    missing_disclosure = [name for name in AUTHORS if not by_name.get(name, {}).get("competing_interests_verbatim")]
    return by_name, ordered_ids, numbers, missing_affiliation, missing_disclosure


def add_author_block(doc, txt, source, material):
    by_name, ordered_ids, numbers, missing_affiliation, missing_disclosure = material
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    plain_authors = []
    for i, name in enumerate(AUTHORS):
        if i:
            font(p.add_run(", "))
        font(p.add_run(name))
        indices = [numbers[v] for v in by_name.get(name, {}).get("source_affiliation_ids", [])]
        if indices:
            run = p.add_run(",".join(indices))
            font(run, 9)
            run.font.superscript = True
        plain_authors.append(name + (" [" + ",".join(indices) + "]" if indices else ""))
    txt.extend([", ".join(plain_authors), ""])
    for identifier in ordered_ids:
        text = source["affiliations"][identifier]
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(5)
        marker = p.add_run(numbers[identifier])
        font(marker, 9)
        marker.font.superscript = True
        font(p.add_run(" " + text), 10.5)
        txt.append(numbers[identifier] + " " + text)
    corresponding = source["correspondence"]
    statement = ("Corresponding author: " + corresponding["name"] + ". " +
                 corresponding["address"] + " Email: " + corresponding["email"])
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_before = Pt(8)
    font(p.add_run(statement), 10.5)
    txt.extend(["", statement, ""])


def add_declarations(doc, txt, source, material):
    by_name, ordered_ids, numbers, missing_affiliation, missing_disclosure = material
    doc.add_paragraph("Funding", "Heading 1")
    funding = ("Bendix Labeit's salary was supported by the Deutsche Forschungsgemeinschaft "
               "(DFG, German Research Foundation), project number 529859742, under the Walter Benjamin Programme.")
    doc.add_paragraph(funding)
    txt.extend(["Funding", funding, ""])
    doc.add_paragraph("Competing interests", "Heading 1")
    txt.extend(["Competing interests", ""])
    for name in AUTHORS:
        statement = by_name.get(name, {}).get("competing_interests_verbatim")
        if statement:
            doc.add_paragraph(statement)
            txt.extend([statement, ""])
    checks = [
        "AUTHOR INFORMATION AND DECLARATION CHECKS",
        "Source: " + source["source"]["path"],
        "Source modification: " + source["source"]["modified_local"],
        "Source SHA-256: " + source["source"]["sha256"],
        "Current author order retained exactly: " + ", ".join(AUTHORS),
        "Affiliations and author-specific disclosures were transferred from the user-identified latest LLM revision, as requested.",
        "No independent update to current employment or disclosure completeness has been inferred.",
        "Unverified or missing affiliation: " + (", ".join(missing_affiliation) or "None"),
        "Unverified or missing competing-interest declaration: " + (", ".join(missing_disclosure) or "None"),
        "Authors with no verified affiliation remain in the author line without an invented superscript. No no-conflict statement was invented for missing declarations.",
        "Funding was limited to the verified named grant and Bendix Labeit's salary support. The prior study's statement that the entire work was supported and its funder-role statement were not transferred to NHIS automatically.",
        "Applicability and timing of this salary support to the NHIS work remain for author review before submission.",
        "The prior paper's equal-contribution claim was not transferred. Author contributions and any institutional ethics determination were not inferred.",
        "Correspondence uses the manuscript title-page email and address; the personal telephone number was not republished.",
    ]
    provenance = ["AUTHOR INFORMATION PROVENANCE", "",
                  "Primary source: " + source["source"]["document_title"],
                  "Latest clean revision: " + source["source"]["modified_local"],
                  "SHA-256: " + source["source"]["sha256"],
                  "The supplied author order was preserved; previous-study contribution roles were not reused.", ""]
    primary_names = {a["name"] for a in source["authors"]}
    for name in AUTHORS:
        if name not in primary_names and by_name.get(name, {}).get("source"):
            prior = by_name[name]["source"]
            url = prior.get("url") or "https://doi.org/" + prior["doi"]
            note = (name + " affiliations were verified in the separate " + str(prior["year"]) +
                    " publication: " + prior["title"] + ". " + url +
                    ". The author-to-affiliation mapping was verified; an NHIS-specific competing-interest disclosure was not inferred.")
            checks.append(note)
            provenance.append(note)
            for label, key in (("Source SHA-256", "sha256"), ("Affiliation page", "affiliation_page_1_based"),
                               ("Disclosure page", "conflicts_page_1_based"), ("DOI", "doi"),
                               ("PubMed URL", "pubmed_url"), ("PMC URL", "pmc_url")):
                if prior.get(key):
                    provenance.append(label + ": " + str(prior[key]))
            provenance.append("")
    (OUT / "author_checks.txt").write_text("\n".join(checks) + "\n", encoding="utf-8")
    (OUT / "author_information_provenance.txt").write_text("\n".join(provenance) + "\n", encoding="utf-8")


def format_table(doc, headers, rows, widths):
    assert abs(sum(widths) - 6.5) < 0.001
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for i, width in enumerate(widths):
        table.columns[i].width = Inches(width)
    for cell, text, width in zip(table.rows[0].cells, headers, widths):
        cell.text = text
        cell.width = Inches(width)
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = str(value)
            cells[i].width = Inches(widths[i])
    pr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement("w:" + edge)
        for key, value in (("val", "single"), ("sz", "4"), ("color", "D9D9D9")):
            el.set(qn("w:" + key), value)
        borders.append(el)
    pr.append(borders)
    for ri, row in enumerate(table.rows):
        trpr = row._tr.get_or_add_trPr()
        no_split = OxmlElement("w:cantSplit")
        trpr.append(no_split)
        if ri == 0:
            repeat = OxmlElement("w:tblHeader")
            repeat.set(qn("w:val"), "true")
            trpr.append(repeat)
        for ci, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            mar = OxmlElement("w:tcMar")
            for edge in ("top", "left", "bottom", "right"):
                item = OxmlElement("w:" + edge)
                item.set(qn("w:w"), "75" if edge in ("top", "bottom") else "90")
                item.set(qn("w:type"), "dxa")
                mar.append(item)
            tcpr.append(mar)
            if ri == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "EAEAEA")
                tcpr.append(shade)
            for p in cell.paragraphs:
                p.paragraph_format.line_spacing = 1.05
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.keep_with_next = ri == 0
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if ci == 0 else WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:
                    font(r, 10, ri == 0)
    return table


def percent(row, interval=True):
    n = float(row["estimate"]) * 100
    if interval:
        return f"{n:.2f} ({float(row['lcl'])*100:.2f} to {float(row['ucl'])*100:.2f})".replace("-", "−")
    return f"{n:.2f}"


def find_result(rows, method, group, kind):
    matches = [r for r in rows if r["analysis"] == method and r["group"] == group
               and r["outcome"] == "any" and r["estimate_type"] == kind]
    if len(matches) != 1:
        raise ValueError((method, group, kind, len(matches)))
    return matches[0]


def tables(doc, txt):
    flow = {r["year"]: r for r in read_tsv(OUT / "sample_flow.tsv")}
    results = read_tsv(OUT / "extensions/primary_comparison_all_methods.tsv")
    title = "Table 1 Sample inclusion and primary outcome counts"
    page_heading(doc, title)
    rows = []
    for label, key in [("All Sample Adult records", "total"), ("Unknown age", "age_unknown"),
                       ("Adults aged 65 years or older", "age65plus"),
                       ("Valid primary outcome", "primary_valid"),
                       ("Reported swallowing problems", "primary_yes"),
                       ("Missing primary outcome", "primary_missing"),
                       ("Reported stroke history among adults 65+", "stroke_yes"),
                       ("Unknown stroke status among adults 65+", "stroke_unknown")]:
        rows.append([label] + [f"{int(flow[y][key]):,}" for y in ("2022", "2025")])
    for g in ("stroke", "no_stroke"):
        rows.append([GROUPS[g] + " with valid primary outcome"] +
                    [f"{int(float(find_result(results, 'main', g, 'standardized_' + y)['n'])):,}"
                     for y in ("2022", "2025")])
    headers = ["Sample or outcome", "2022 n", "2025 n"]
    format_table(doc, headers, rows, [4.3, 1.1, 1.1])
    note = "All counts are unweighted. Outcome-specific missing responses are excluded from prevalence estimation. Unknown stroke status affects subgroup analyses but does not exclude a valid response from the overall analysis."
    add_note(doc, note)
    txt.extend([title, "\t".join(headers)] + ["\t".join(r) for r in rows] + [note, ""])

    title = "Table 2 Primary age standardized prevalence and between year differences"
    page_heading(doc, title)
    headers = ["Population", "2022 prevalence %\n95% CI", "2025 prevalence %\n95% CI", "Difference pp\n95% CI"]
    rows = [[GROUPS[g], percent(find_result(results, "main", g, "standardized_2022")),
             percent(find_result(results, "main", g, "standardized_2025")),
             percent(find_result(results, "main", g, "difference_2025_minus_2022"))] for g in GROUPS]
    format_table(doc, headers, rows, [1.5, 1.6, 1.6, 1.8])
    note = ("CI, confidence interval; pp, percentage points. Differences are 2025 minus 2022. "
            "Direct age standardization uses the US 2000 population within ages 65 years and older. "
            "Intervals account for weights, strata, clusters and covariance of the joint estimates. "
            "The overall population includes unknown stroke status and overlaps both subgroups. "
            "Subgroup analyses are exploratory and intervals are not adjusted for multiplicity.")
    add_note(doc, note)
    txt.extend([title, "\t".join(h.replace("\n", " ") for h in headers)] + ["\t".join(r) for r in rows] + [note, ""])

    title = "Table 3 Primary outcome comparisons across four analysis methods"
    page_heading(doc, title)
    headers = ["Method", "Population", "2022 %", "2025 %", "Difference pp\n95% CI"]
    rows = []
    for method, label in METHODS.items():
        for group in GROUPS:
            rows.append([label, GROUPS[group],
                         percent(find_result(results, method, group, "standardized_2022"), False),
                         percent(find_result(results, method, group, "standardized_2025"), False),
                         percent(find_result(results, method, group, "difference_2025_minus_2022"))])
    format_table(doc, headers, rows, [1.65, 1.1, 0.75, 0.75, 2.25])
    note = ("CI, confidence interval; pp, percentage points. Model-adjusted estimates use the US 2000 age standard crossed with a fixed 50:50 male:female distribution, a hypothetical reference population. "
            "Self-response restriction uses conservative year-specific classifications and changes the target population. "
            "The additional methods were specified after inspection of the original results; all are exploratory and unadjusted for multiplicity. "
            "Small changes in denominators for adjusted models reflect missing sex information. These analyses do not remove the 2025 collection-interruption limitation.")
    add_note(doc, note)
    txt.extend([title, "\t".join(h.replace("\n", " ") for h in headers)] +
               ["\t".join(x.replace("\n", "; ") for x in r) for r in rows] + [note, ""])


def read_captions():
    # The staged caption file contains the original exact captions plus Figure 4.
    candidates = [OUT / "figures/Figure_captions_EN.txt",
                  ROOT / "work/repository/outputs/figures/Figure_captions_EN.txt"]
    selected = None
    for p in candidates:
        if p.exists() and re.search(r"^Figure 4\.", p.read_text(encoding="utf-8-sig"), re.M):
            selected = p
            break
    if selected is None:
        raise FileNotFoundError("A complete source caption file with Figures 1 to 4 is required")
    raw = selected.read_text(encoding="utf-8-sig")
    parsed = {}
    for n in range(1, 5):
        m = re.search(rf"^Figure {n}\. ([^\n]+)\n(.*?)(?=^Figure \d\.|^Shared methods|^Suggested manuscript placement|\Z)", raw, re.M | re.S)
        if not m:
            raise ValueError(f"Caption {n} is missing")
        parsed[n] = (m.group(1).strip(), m.group(2).strip())
    shared = re.search(r"^Shared methods and source statement\s*\n(.*?)(?=^Suggested manuscript placement|^Figure 4\.|\Z)", raw, re.M | re.S)
    if not shared:
        raise ValueError("Shared figure methods missing")
    return parsed, shared.group(1).strip(), selected


def append_figures(doc, txt):
    captions, shared, source = read_captions()
    page_heading(doc, "Figure legends")
    txt.extend(["Figure legends", ""])
    for n in range(1, 5):
        heading, body = captions[n]
        p = doc.add_paragraph(f"Figure {n}", "Heading 2")
        # Preserve the exact caption title as prose, separate from punctuation-free headings.
        title = doc.add_paragraph()
        title.paragraph_format.keep_with_next = True
        font(title.add_run(heading), 11, True)
        txt.extend([f"Figure {n}. {heading}", body, ""])
        for text in body.split("\n\n"):
            doc.add_paragraph(" ".join(text.split()))
    doc.add_paragraph("Shared methods and source statement", "Heading 2")
    for text in shared.split("\n\n"):
        doc.add_paragraph(" ".join(text.split()))
    txt.extend(["Shared methods and source statement", shared, ""])
    for n, name in enumerate(FIGURES, 1):
        page_heading(doc, f"Figure {n}")
        path = OUT / "figures" / name
        with Image.open(path) as img:
            width, height = img.size
        available_width, available_height = 6.5, 8.0
        inches = min(available_width, available_height * width / height)
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = 1
        shape = p.add_run().add_picture(str(path), width=Inches(inches))
        shape._inline.docPr.set("descr", captions[n][0])
        shape._inline.docPr.set("title", f"Figure {n}")
        txt.append(f"Figure {n} image: figures/{name}")
    return str(source)


def write_preferences(path, custom_properties):
    props = etree.Element(f"{{{NS_CP}}}Properties", nsmap={None: NS_CP, "vt": NS_VT})
    for i, prop in enumerate(custom_properties, 2):
        if len(prop["value"]) > 255:
            raise ValueError("Zotero preference property exceeds 255 characters")
        p = etree.SubElement(props, f"{{{NS_CP}}}property",
                             fmtid="{D5CDD505-2E9C-101B-9397-08002B2CF9AE}", pid=str(i), name=prop["name"])
        etree.SubElement(p, f"{{{NS_VT}}}lpwstr").text = prop["value"]
    with zipfile.ZipFile(path) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    parts["docProps/custom.xml"] = etree.tostring(props, encoding="UTF-8", xml_declaration=True, standalone=True)
    rels = etree.fromstring(parts["_rels/.rels"])
    reltype = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties"
    for r in list(rels):
        if r.get("Type") == reltype:
            rels.remove(r)
    etree.SubElement(rels, f"{{{NS_REL}}}Relationship", Id="rIdZoteroCustom", Type=reltype, Target="docProps/custom.xml")
    parts["_rels/.rels"] = etree.tostring(rels, encoding="UTF-8", xml_declaration=True, standalone=True)
    content_types = etree.fromstring(parts["[Content_Types].xml"])
    for e in list(content_types):
        if e.get("PartName") == "/docProps/custom.xml":
            content_types.remove(e)
    etree.SubElement(content_types, f"{{{NS_CT}}}Override", PartName="/docProps/custom.xml",
                     ContentType="application/vnd.openxmlformats-officedocument.custom-properties+xml")
    parts["[Content_Types].xml"] = etree.tostring(content_types, encoding="UTF-8", xml_declaration=True, standalone=True)
    temp = path.with_suffix(".temp.docx")
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in parts.items():
            z.writestr(name, content)
    temp.replace(path)


def validate(path, citation_data, body):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        xml = etree.fromstring(z.read("word/document.xml"))
        codes = xml.findall(".//" + qn("w:instrText"))
        citation_codes = [x.text for x in codes if "ZOTERO_ITEM" in (x.text or "")]
        assert len(citation_codes) == len(citation_data["citations"])
        assert sum("ZOTERO_BIBL" in (x.text or "") for x in codes) == 1
        for code in citation_codes:
            parsed = json.loads(code.split("CSL_CITATION", 1)[1].strip())
            assert parsed["citationItems"]
            assert all(item.get("uris") and item.get("itemData") for item in parsed["citationItems"])
        markers = xml.findall(".//" + qn("w:fldChar"))
        assert sum(e.get(qn("w:fldCharType")) == "begin" for e in markers) == len(citation_codes) + 1
        assert sum(e.get(qn("w:fldCharType")) == "end" for e in markers) == len(citation_codes) + 1
        assert len(xml.findall(".//" + qn("w:tbl"))) == 3
        assert len([n for n in z.namelist() if n.startswith("word/media/")]) == 4
        props = etree.fromstring(z.read("docProps/custom.xml"))
        pref = "".join(e[0].text or "" for e in sorted(props, key=lambda e: int(e.get("name").rsplit("_", 1)[1])))
        assert pref == citation_data["documentPreferences"]["serialized"]
        etree.fromstring(pref.encode("utf-8"))
    report = ["Structural checks passed; visual review remains required.",
              f"Author count: {len(AUTHORS)}; exact supplied order retained.",
              f"Body blocks: {len(body)}; Zotero citation fields: {len(citation_codes)}.",
              f"Bibliography entries: {len(citation_data['bibliography']['entries'])}; one live bibliography field.",
              "Three tables and four embedded figure images verified.",
              "ZOTERO_PREF chunks reassemble to the supplied preference XML.",
              "No renderer was launched by this script."]
    (ROOT / "work/manuscript_structural_validation.txt").write_text("\n".join(report) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--approve-create", action="store_true",
                        help="Root agent confirms the required artifact marker has run")
    args = parser.parse_args()
    if not args.approve_create:
        parser.error("Creation is gated: root must run the marker and then pass --approve-create")
    body = read_json(ROOT / "work/manuscript_body.json")
    citation_data = read_json(OUT / "literature/zotero_manuscript_citations.json")
    author_source = read_json(ROOT / "work/author_information_source.json")
    material = author_material(author_source)
    by_block = {c["blockIndex"]: c for c in citation_data["citations"]}
    if len(by_block) != len(citation_data["citations"]):
        raise ValueError("Duplicate citation block index")
    for i, block in enumerate(body):
        if block["refs"]:
            assert i in by_block and by_block[i]["refIDs"] == block["refs"], f"Citation mismatch in block {i}"
        else:
            assert i not in by_block
    doc = Document()
    configure(doc)
    txt = []
    for i, block in enumerate(body):
        kind, text = block["type"], block["text"]
        if kind in ("title", "subtitle", "heading"):
            text = plain_heading(text)
        if kind == "title":
            doc.add_paragraph(text, "Title")
            doc.core_properties.title = text
            txt.extend([text, ""])
            continue
        if kind == "subtitle":
            p = doc.add_paragraph(text, "Subtitle")
            txt.extend([text, ""])
            add_author_block(doc, txt, author_source, material)
            continue
        elif kind == "heading":
            p = doc.add_paragraph(text, "Heading 1")
            if text == "Abstract":
                p.paragraph_format.page_break_before = True
        else:
            p = doc.add_paragraph(text)
        if i in by_block:
            add_citation(p, by_block[i])
            text += " " + by_block[i]["plainCitation"]
        txt.extend([text, ""])
    add_declarations(doc, txt, author_source, material)
    page_heading(doc, "References")
    txt.extend(["References", ""])
    bibliography = citation_data["bibliography"]
    entries = bibliography["entries"]
    assert entries
    for i, entry in enumerate(entries):
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.left_indent = Inches(0.25)
        p.paragraph_format.first_line_indent = Inches(-0.25)
        if i == 0:
            begin_field(p, bibliography["fieldCode"])
        font(p.add_run(entry["text"]), 10.5)
        if i == len(entries) - 1:
            end_field(p)
        txt.append(entry["text"])
    txt.append("")
    tables(doc, txt)
    source = append_figures(doc, txt)
    output = OUT / "NHIS_Manuscript.docx"
    doc.save(output)
    write_preferences(output, citation_data["documentPreferences"]["customProperties"])
    (OUT / "NHIS_Manuscript.txt").write_text("\n".join(txt) + "\n", encoding="utf-8")
    validate(output, citation_data, body)
    print(json.dumps({"docx": str(output), "text": str(OUT / "NHIS_Manuscript.txt"),
                      "caption_source": source, "citations": len(by_block), "references": len(entries)}))


if __name__ == "__main__":
    main()
