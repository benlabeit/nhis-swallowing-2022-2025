Journal artwork - four English figures
Use Fig1.png through Fig4.png in Word at a width of 165 mm.
Use Fig1.pdf through Fig4.pdf, or the corresponding EPS files, for vector submission.
PNG images are 600 dpi; SVG copies are also provided.
Do not add titles or figure captions to the artwork; supply them separately in the manuscript.
Captions must explain the symbols, confidence intervals, exploratory analyses and source limitations.
Fig2 uses the label Substantial difficulties for the existing severe outcome; the numeric endpoint is unchanged.
Reproduce from project root: Rscript work/dysphagia/build_figures.R
Original outputs/figures files remain unchanged.
