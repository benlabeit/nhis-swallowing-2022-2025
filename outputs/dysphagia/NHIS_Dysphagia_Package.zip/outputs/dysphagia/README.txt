DYSPHAGIA MANUSCRIPT FILES
Prepared 6 November 2026

Title: Swallowing Difficulties in Older US Adults by Stroke History in 2022 and 2025

NHIS_Dysphagia_Manuscript.docx is the anonymized manuscript for peer review.
NHIS_Dysphagia_Zotero_Master.docx is the identified, editable working copy with live Zotero references. It must not be uploaded as an anonymous reviewer file.
NHIS_Dysphagia_Author_Information.docx holds the verified author details and declarations for transfer to the submission portal. The current SNAPP workflow requests author information through portal fields; follow the fields presented at submission.

The abstract has 250 words and six keywords are supplied. The manuscript uses plain Times New Roman, automatic page numbers, editable Word tables, and figures with external captions. The chosen 11-point text and 1.5 line spacing are readability choices, not additional journal requirements. References use numeric brackets in first-citation order, journal abbreviations, and DOI links. The review copy contains static Zotero-generated citations; the working master retains the live fields. The project citation style is supplied in the package and installed in the local Zotero library.

Figure files are under figures/: Fig1 through Fig4 in PDF, EPS, SVG and 600-dpi PNG formats. Their numerical estimates are unchanged. Figure-generation software: R with grid and Cairo graphics. Vector fonts are embedded. Captions are included in the manuscript.

Official guidance checked 6 November 2026:
https://link.springer.com/journal/455/submission-guidelines
https://www.springernature.com/gp/snapp/submitting/how-to-submit/double-anonymous

ORIGINAL DATA
The exact original CSV tables are supplied separately in outputs/data_original and in the journal package. They have not been recoded or filtered.
2022: adult22.csv, 27,651 records and 637 variables
2025: adult25.csv, 24,215 records and 577 variables
Official downloads (ZIP containing the CSV):
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2022/adult22csv.zip
https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip
Both download links are clickable in the manuscript's Data availability section.

AUTHOR REVIEW BEFORE SUBMISSION
The files have been prepared for review and formatting; no journal submission has been made.
The prior author checks remain applicable: confirm Anel Karisik's current competing-interest disclosure, the applicability of the named salary support to this study, author contributions, and the study-specific institutional ethics/consent determination. No approval or exemption has been invented. Confirm the description of generative AI assistance in Methods. All authors must approve the content and portal declarations before submission. Contact telephone/fax and ORCID details can be entered in the portal if requested; they were not invented.
The identified original GitHub repository is private. It is not presented as publicly available or linked from the anonymous manuscript.
