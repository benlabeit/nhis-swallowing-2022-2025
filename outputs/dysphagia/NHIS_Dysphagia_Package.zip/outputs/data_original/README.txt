NHIS original public-use data - 6 November 2026

These are the unchanged CDC Sample Adult files downloaded for the analysis.
adult22csv.zip and adult25csv.zip are the original downloaded archives.
adult22.csv and adult25.csv are byte-identical to the CSV entries in those archives.
They have not been filtered, recoded, merged, weighted, or reformatted.

The TSV manifest records SHA-256, byte sizes, row and column counts, and official source URLs.
Rows exclude the header. Counts describe all Sample Adults, not only the age-65+ study population.
NHIS 2022: 27,651 adult records.
NHIS 2025: 24,215 adult records.

All recoding and age restrictions are applied separately by outputs/01_prepare.R.
The CSVs retain NHIS nonresponse codes and structural blanks; these must not be treated as valid numeric observations.
HHX identifies records within a year and must not be used to infer longitudinal linkage across years.

The repository stores the original ZIP archives under work/raw, rather than duplicating the large CSVs.
Running outputs/01_prepare.R extracts the CSVs and regenerates the analysis dataset.
The local deliverable NHIS_Original_Data.zip includes both original archives, both unchanged CSVs, and this manifest.

Data source: National Center for Health Statistics, National Health Interview Survey.
Use is subject to the NHIS data-use terms in the official Survey Description, including no attempted identification.
https://www.cdc.gov/nchs/nhis/documentation/2022-nhis.html
https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html
