"""Minimal layout adjustment after native Word/Zotero Refresh and Save.

Close the master in Word before running. Uses only OOXML; changes no text,
citation instructions, citation preferences, or anonymous submission file.
Re-export the master PDF in Word and inspect the reference pages afterwards.
"""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
MASTER = ROOT / 'outputs/dysphagia/NHIS_Dysphagia_Zotero_Master.docx'
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
q = lambda name: '{' + NS['w'] + '}' + name
PPR_ORDER = ['pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr',
             'widowControl', 'numPr', 'suppressLineNumbers', 'pBdr', 'shd', 'tabs',
             'suppressAutoHyphens', 'kinsoku', 'wordWrap', 'overflowPunct',
             'topLinePunct', 'autoSpaceDE', 'autoSpaceDN', 'bidi', 'adjustRightInd',
             'snapToGrid', 'spacing', 'ind', 'contextualSpacing', 'mirrorIndents',
             'suppressOverlap', 'jc', 'textDirection', 'textAlignment',
             'textboxTightWrap', 'outlineLvl', 'divId', 'cnfStyle', 'rPr', 'sectPr',
             'pPrChange']

def get(parent, name):
    node = parent.find('w:' + name, NS)
    if node is None:
        node = E.SubElement(parent, q(name))
    return node

def order_ppr(pp):
    rank = {q(name): index for index, name in enumerate(PPR_ORDER)}
    for child in sorted(list(pp), key=lambda node: rank.get(node.tag, 1000)):
        pp.append(child)

def paragraph_format(pp):
    get(pp, 'keepLines').set(q('val'), '1')
    get(pp, 'keepNext').set(q('val'), '0')
    spacing = get(pp, 'spacing')
    spacing.set(q('line'), '240')
    spacing.set(q('lineRule'), 'auto')
    order_ppr(pp)

def main():
    with ZipFile(MASTER) as archive:
        infos = archive.infolist()
        parts = {info.filename: archive.read(info.filename) for info in infos}
    hashes = {name: hashlib.sha256(data).hexdigest() for name, data in parts.items()}
    doc = E.fromstring(parts['word/document.xml'])
    styles = E.fromstring(parts['word/styles.xml'])
    text_before = doc.xpath('.//w:t/text()', namespaces=NS)
    codes_before = doc.xpath('.//w:instrText/text()', namespaces=NS)
    custom = E.fromstring(parts['docProps/custom.xml'])
    chunks = sorted((int(node.get('name').rsplit('_', 1)[1]), ''.join(node.itertext()))
                    for node in custom if node.get('name', '').startswith('ZOTERO_PREF_'))
    prefs = E.fromstring(''.join(value for _, value in chunks).encode())
    assert prefs.find('style').get('bibliographyStyleHasBeenSet') == '1', 'Complete native Zotero Refresh and Save first'
    assert prefs.find('style').get('id') == 'http://www.zotero.org/styles/nhis-dysphagia-basic-brackets'

    style = styles.find("w:style[@w:styleId='Literaturverzeichnis']", NS)
    assert style is not None
    paragraph_format(get(style, 'pPr'))
    rpr = get(style, 'rPr')
    get(rpr, 'sz').set(q('val'), '22')
    get(rpr, 'szCs').set(q('val'), '22')
    fonts = get(rpr, 'rFonts')
    for attribute in list(fonts.attrib):
        if E.QName(attribute).localname.lower().endswith('theme'):
            del fonts.attrib[attribute]
    for attribute in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        fonts.set(q(attribute), 'Times New Roman')
    rpr.insert(0, fonts)

    count = heading_count = 0
    for para in doc.findall('.//w:p', NS):
        text = ''.join(para.xpath('.//w:t/text()', namespaces=NS))
        pp = para.find('w:pPr', NS)
        pstyle = pp.find('w:pStyle', NS) if pp is not None else None
        if pstyle is not None and pstyle.get(q('val')) == 'Literaturverzeichnis' and text.strip():
            paragraph_format(pp)
            count += 1
        if text == 'References':
            pp = get(para, 'pPr')
            get(pp, 'pageBreakBefore').set(q('val'), '1')
            get(pp, 'keepNext').set(q('val'), '1')
            order_ppr(pp)
            heading_count += 1
    assert count == 25 and heading_count == 1
    assert text_before == doc.xpath('.//w:t/text()', namespaces=NS)
    assert codes_before == doc.xpath('.//w:instrText/text()', namespaces=NS)
    parts['word/document.xml'] = E.tostring(doc, xml_declaration=True, encoding='UTF-8', standalone=True)
    parts['word/styles.xml'] = E.tostring(styles, xml_declaration=True, encoding='UTF-8', standalone=True)
    changed = [name for name, data in parts.items() if hashes[name] != hashlib.sha256(data).hexdigest()]
    assert set(changed).issubset({'word/document.xml', 'word/styles.xml'})
    temp = MASTER.with_name(MASTER.stem + '.layout-tmp.docx')
    with ZipFile(temp, 'w') as archive:
        for info in infos:
            archive.writestr(info, parts[info.filename])
    temp.replace(MASTER)
    print(json.dumps({'bibliographyParagraphs': count, 'fontPoints': 11,
                      'singleLine': True, 'keepLines': True, 'keepNext': False,
                      'referencesStartNewPage': True, 'changedParts': changed,
                      'textAndFieldCodesUnchanged': True}))

if __name__ == '__main__':
    main()
