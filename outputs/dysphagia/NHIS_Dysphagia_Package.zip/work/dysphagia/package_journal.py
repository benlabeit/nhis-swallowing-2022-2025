"""Package final journal deliverables only after the coordinator confirms them.

Run from the project root:
    python work/dysphagia/package_journal.py --final-files-ready
No analysis, document formatting, or Zotero refresh is performed by this script.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT / "outputs/NHIS_Dysphagia_Package.zip"
LIMIT_BYTES = 25_000_000

# Preserve project-relative paths because the journal scripts use these paths.
# The earlier final DOCX is an input to the journal formatter, not a new final.
REQUIRED = [
    "outputs/NHIS_Manuscript_Final.docx",
    "outputs/standardized_results.tsv",
    "outputs/cell_counts.tsv",
    "outputs/extensions/primary_comparison_all_methods.tsv",
    "outputs/data_original/adult22.csv",
    "outputs/data_original/adult25.csv",
    "outputs/data_original/original_data_manifest.tsv",
    "outputs/data_original/README.txt",
    "outputs/author_checks.txt",
    "outputs/author_information_provenance.txt",
    "work/raw/adult22csv.zip",
    "work/raw/adult25csv.zip",
    "work/manuscript_body.json",
    "work/zotero_import_export.js",
    "work/dysphagia/build_figures.R",
    "work/dysphagia/format_manuscript.py",
    "work/dysphagia/check_figures.py",
    "work/dysphagia/check_citations_anonymization.py",
    "work/dysphagia/apply_dysphagia_in_zotero.js",
    "work/dysphagia/metadata_updates.json",
    "work/dysphagia/nhis-dysphagia-basic-brackets.csl",
    "work/dysphagia/zotero_dysphagia_bibliography.json",
    "work/dysphagia/zotero_dysphagia_citations.json",
    "work/dysphagia/zotero_dysphagia_references.txt",
    "work/dysphagia/citation_anonymization_check.txt",
    "work/dysphagia/format_validation.json",
    "work/dysphagia/style_and_metadata_audit.txt",
    "work/dysphagia/package_journal.py",
]

POST_REFRESH_FILES = [
    "work/dysphagia/format_master_bibliography_after_refresh.py",
]

README = """# NHIS Dysphagia journal package

The current journal files are in `outputs/dysphagia/`:

- `NHIS_Dysphagia_Manuscript.docx`: anonymized review manuscript; references are static Zotero-generated text.
- `NHIS_Dysphagia_Zotero_Master.docx`: identified working master with live Zotero citations and bibliography.
- `NHIS_Dysphagia_Author_Information.docx`: identified author details and declarations for the submission portal.
- `figures/Fig1` through `Fig4`: PDF, EPS and SVG vector artwork, 600-dpi PNGs, plotted values and validation records. Figure captions are in the manuscript.
- `nhis-dysphagia-basic-brackets.csl`: the separate project citation style.

The archive also contains identified working materials, author provenance and an earlier identified source manuscript. It is a project handover archive, not an anonymous reviewer upload. Use only the designated anonymous DOCX as the review manuscript and follow the journal's portal fields for author information. No submission is made by any included script. Read `outputs/dysphagia/README.txt` and `outputs/author_checks.txt` before submission.

## Original data

`outputs/data_original/adult22.csv` and `adult25.csv` are the complete unchanged source tables, before analytical exclusions. They contain 27,651 rows and 637 columns (2022), and 24,215 rows and 577 columns (2025), excluding the header row. The unchanged downloaded CDC ZIP files are stored once, under `work/raw/`. The original-data manifest records SHA-256 hashes, exact file sizes, table dimensions and official download URLs. No original CSV or ZIP is modified by the packaging process.

- https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2022/adult22csv.zip
- https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip
- https://www.cdc.gov/nchs/nhis/documentation/2022-nhis.html
- https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html

## Scope and the complete analysis project

This journal package contains the existing estimates and the inputs needed for the supplied journal figure and document-formatting helpers. It does not contain the complete statistical-analysis pipeline or the official codebook/Survey Description PDFs and does not claim standalone reproduction of the statistical analyses. The previously completed full analysis project, including the original R analysis scripts and documentation, is maintained in the existing private GitHub repository:

https://github.com/benlabeit/nhis-swallowing-2022-2025

Repository access requires authorization. The identified repository is not linked from the anonymous manuscript. The complete local analysis handover was delivered separately as `NHIS_Research_Package.zip`.

`outputs/NHIS_Manuscript_Final.docx` is the earlier pre-journal source required by `format_manuscript.py`. It is retained solely for reproduction of the journal adaptation; the user-facing current journal documents are the files in `outputs/dysphagia/`.

## Reproduce journal artwork and document formatting

Extract the archive to a new working folder and run commands from that folder. Regeneration overwrites generated files in that extracted copy. Python needs `python-docx`, `lxml`, `Pillow`, and `pypdf`; R needs its standard `grid` and graphics libraries, Cairo support, and Arial fonts. The original artwork used R 4.6.0; software details are in `outputs/dysphagia/figures/software.txt`.

```
Rscript work/dysphagia/build_figures.R
python work/dysphagia/check_figures.py
python work/dysphagia/format_manuscript.py
python work/dysphagia/check_citations_anonymization.py
```

The figure script reads exactly three included aggregate tables: `outputs/standardized_results.tsv`, `outputs/cell_counts.tsv`, and `outputs/extensions/primary_comparison_all_methods.tsv`. It does not re-estimate survey models. The document formatter reads the earlier source DOCX, the four current figure PNGs, and `work/dysphagia/zotero_dysphagia_bibliography.json`; it retains the source numerical tables and uses the saved native Zotero citation export.

The formatter creates the pre-refresh working documents, not a byte-identical copy of the Word-saved final master. Open the regenerated master in Microsoft Word with Zotero's Word add-in, install the supplied CSL, perform native Zotero Refresh, save, and close the master in Word. Then run:

```
python work/dysphagia/format_master_bibliography_after_refresh.py
```

That helper requires a successfully saved native Refresh and adjusts only the master's bibliography style and 25 reference paragraphs to 11-point type, single spacing and intact entries, with References beginning on a new page. The final manual step is to export from Word and visually inspect every page, including figure/table captions and bibliography entry breaks. Native Refresh may replace direct bibliography paragraph formatting, so the final layout correction follows the last Refresh. Keep the identified master separate from the anonymized review copy. Recheck both documents after any substantive edit or new refresh. The supplied audit reports document the original run only and are not proof of checks on a later regeneration.

## Zotero and literature

`outputs/literature/` contains the earlier targeted narrative search record, evidence table, reference metadata and native library exports. The authoritative journal-specific rendering and 25-item metadata export is `work/dysphagia/zotero_dysphagia_bibliography.json`; its companion citation export contains 19 citation clusters. The offline preview files and rendering screenshots are deliberately omitted.

`work/dysphagia/apply_dysphagia_in_zotero.js` is a Zotero Run JavaScript helper for the original 25-item library. It is not a Node.js program. Its stored absolute project paths must be updated before reuse. It verifies original item identities before modifying the permitted metadata fields, installs the separate project CSL, and writes native exports. On a different Zotero library, first import the supplied reference metadata using `work/zotero_import_export.js`, then explicitly remap and verify item IDs/keys in the journal update plan; do not reuse the original library IDs blindly. The saved native export allows figure/document inspection without accessing the original account.

The literature search is targeted and narrative, not systematic. The original metadata audit predates native execution; final checks and native export proof supersede its historical work-status notes.

## Package integrity and rights

`journal_package_manifest.tsv` lists the size and SHA-256 of every packaged source file and generated README/requirements file. It excludes itself. The packaging script verifies original-data files against their existing source manifest and checks ZIP integrity. It does not rerun scientific analyses, refresh Zotero, or change source files.

No new license for the manuscript or project materials is asserted. CDC data-use conditions and the license attribution already present in the supplied CSL remain applicable. No official endorsement is implied.
"""


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def excluded(path: Path) -> bool:
    parts = {part.lower() for part in path.parts}
    return (any(part.startswith(".") for part in path.parts)
            or path.name.startswith("~$")
            or bool(parts & {"__pycache__", "screenshots", "temp", "tmp"})
            or "_qa" in path.stem.lower()
            or "screenshot" in path.stem.lower()
            or path.suffix.lower() in {".zip", ".tmp", ".pyc"})


def collect() -> dict[str, Path]:
    paths = {name: ROOT / name for name in REQUIRED + POST_REFRESH_FILES}
    for directory in ("outputs/dysphagia", "outputs/literature"):
        for path in sorted((ROOT / directory).rglob("*")):
            if path.is_file() and not excluded(path.relative_to(ROOT)):
                paths[path.relative_to(ROOT).as_posix()] = path
    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"Required package input missing: {name}")
        if not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError(f"Package input leaves project: {name}")
    for name in ("NHIS_Dysphagia_Manuscript.docx", "NHIS_Dysphagia_Zotero_Master.docx", "NHIS_Dysphagia_Author_Information.docx"):
        assert "outputs/dysphagia/" + name in paths
    assert POST_REFRESH_FILES, "List the final post-refresh helper before releasing the package."
    return dict(sorted(paths.items()))


def verify_original_data() -> None:
    path = ROOT / "outputs/data_original/original_data_manifest.tsv"
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    assert len(rows) == 4
    for row in rows:
        base = "work/raw" if row["file"].endswith(".zip") else "outputs/data_original"
        original = ROOT / base / row["file"]
        assert original.stat().st_size == int(row["bytes"]), original
        assert digest(original) == row["sha256"], original


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--final-files-ready", action="store_true", help="Use only after the coordinator confirms the final files.")
    args = parser.parse_args()
    if not args.final_files_ready:
        parser.error("Final files have not been confirmed; pass --final-files-ready only after the coordinator's signal.")
    paths = collect()
    verify_original_data()
    generated = {
        "README.md": README.encode("utf-8"),
        "requirements-journal.txt": b"python-docx\nlxml\nPillow\npypdf\n",
    }
    manifest = io.StringIO(newline="")
    writer = csv.writer(manifest, delimiter="\t", lineterminator="\n")
    writer.writerow(["file", "bytes", "sha256"])
    source_hashes = {name: digest(path) for name, path in paths.items()}
    for name, path in paths.items():
        writer.writerow([name, path.stat().st_size, source_hashes[name]])
    for name, data in generated.items():
        writer.writerow([name, len(data), hashlib.sha256(data).hexdigest()])
    generated["journal_package_manifest.tsv"] = manifest.getvalue().encode("utf-8")
    temporary = DESTINATION.with_suffix(".building.zip")
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        for name, data in generated.items():
            archive.writestr(name, data)
    size = temporary.stat().st_size
    if size >= LIMIT_BYTES:
        raise ValueError(f"Package is {size:,} bytes and exceeds the {LIMIT_BYTES:,}-byte limit; unpublished temporary archive retained.")
    with ZipFile(temporary) as archive:
        assert archive.testzip() is None, "ZIP CRC integrity check failed"
        assert len(archive.namelist()) == len(set(archive.namelist()))
        for name, path in paths.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == source_hashes[name], name
            assert digest(path) == source_hashes[name], f"Source changed during packaging: {name}"
        count = len(archive.namelist())
    temporary.replace(DESTINATION)
    result = {"created_utc": datetime.now(timezone.utc).isoformat(),
              "archive": DESTINATION.relative_to(ROOT).as_posix(),
              "bytes": size, "file_count": count,
              "sha256": digest(DESTINATION), "below_25000000_bytes": True,
              "original_data_manifest_matches": True, "zip_integrity": "PASS",
              "source_files_unchanged_during_packaging": True,
              "scope": "Journal deliverables, formatting inputs, originals and literature; not standalone statistical analysis reproduction"}
    (ROOT / "work/dysphagia/package_validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
