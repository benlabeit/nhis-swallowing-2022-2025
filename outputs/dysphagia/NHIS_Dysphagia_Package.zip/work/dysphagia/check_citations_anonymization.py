"""Read-only DOCX checks; writes only the requested audit report."""
import json
import re
import hashlib
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime, timezone
from lxml import etree as E

ROOT = Path(__file__).resolve().parents[2]
DIR = ROOT / 'outputs/dysphagia'
native = json.loads((ROOT / 'work/dysphagia/zotero_dysphagia_bibliography.json').read_text(encoding='utf-8-sig'))
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
q = lambda name: '{' + W + '}' + name
norm = lambda text: re.sub(r'\s+', ' ', text).strip()
errors, passes, notes = [], [], []
def check(condition, message):
    (passes if condition else errors).append(message)

def load(name):
    path = DIR / name
    with ZipFile(path) as archive:
        data = {name: archive.read(name) for name in archive.namelist()}
    doc = E.fromstring(data['word/document.xml'])
    return {'path': path, 'data': data, 'doc': doc,
            'paragraphs':doc.findall('.//w:p', NS),
            'styles':E.fromstring(data['word/styles.xml']),
            'hash':hashlib.sha256(path.read_bytes()).hexdigest()}

def fields(doc):
    stack, complete = [], []
    pindex = -1
    for event,node in E.iterwalk(doc, events=('start','end')):
        if event=='start' and node.tag==q('p'): pindex += 1
        if event!='end': continue
        if node.tag==q('fldChar'):
            kind=node.get(q('fldCharType'))
            if kind=='begin': stack.append({'code':'','phase':'code','texts':{},'text':''})
            elif kind=='separate': stack[-1]['phase']='result'
            elif kind=='end': complete.append(stack.pop())
        elif node.tag==q('instrText') and stack: stack[-1]['code']+=node.text or ''
        elif node.tag==q('t') and stack and stack[-1]['phase']=='result':
            stack[-1]['text']+=node.text or ''
            stack[-1]['texts'][pindex]=stack[-1]['texts'].get(pindex,'')+(node.text or '')
    check(not stack,'All complex fields are balanced')
    return complete

def effective_numpr(paragraph, styles):
    direct=paragraph.find('w:pPr/w:numPr',NS)
    if direct is not None: return direct
    style_tag=paragraph.find('w:pPr/w:pStyle',NS)
    style_id=style_tag.get(q('val')) if style_tag is not None else 'Standard'
    seen=set()
    while style_id and style_id not in seen:
        seen.add(style_id)
        style=styles.find("w:style[@w:styleId='%s']"%style_id,NS)
        if style is None: break
        num=style.find('w:pPr/w:numPr',NS)
        if num is not None: return num
        parent=style.find('w:basedOn',NS)
        style_id=parent.get(q('val')) if parent is not None else None
    return None

master=load('NHIS_Dysphagia_Zotero_Master.docx')
submission=load('NHIS_Dysphagia_Manuscript.docx')
master_fields=fields(master['doc'])
citation_fields=[f for f in master_fields if 'ZOTERO_ITEM CSL_CITATION' in f['code']]
bib_fields=[f for f in master_fields if 'ZOTERO_BIBL' in f['code']]
check(len(citation_fields)==19,'Master has exactly 19 live Zotero citation clusters')
check(len(bib_fields)==1,'Master has exactly one live Zotero bibliography field')
by_id={str(item['id']):item for item in native['items']}
seen_ids,seen_uris=set(),set()
for field,expected in zip(citation_fields,native['citations']):
    citation=json.loads(field['code'].split('CSL_CITATION',1)[1].strip())
    check(citation['citationID']==expected['citationID'],'Citation ID/order matches: '+expected['citationID'])
    check([str(item['id']) for item in citation['citationItems']]==[str(item['id']) for item in expected['citation']['citationItems']], 'Item sequence matches: '+expected['citationID'])
    check(norm(field['text'])==norm(expected['plainCitation']),'Cached citation matches native CSL: '+expected['citationID'])
    for item in citation['citationItems']:
        actual_id=str(item['id']); reference=by_id[actual_id]
        check(reference['uri'] in item['uris'],'Real URI retained: '+reference['refID'])
        seen_ids.add(actual_id);seen_uris.update(item['uris'])
        expected_data=reference['cslData']
        for key in ('title','DOI','page','journalAbbreviation'):
            check(item['itemData'].get(key)==expected_data.get(key),'Embedded '+key+' matches native item: '+reference['refID'])
check(len(seen_ids)==25 and seen_ids==set(by_id),'All 25 real Zotero item IDs retained')
check(seen_uris=={item['uri'] for item in native['items']},'All 25 real Zotero item URIs retained')
check(sum(bool(item['cslData'].get('journalAbbreviation')) for item in native['items'])==20,'Native export has all 20 journal abbreviations')
check(next(item for item in native['items'] if item['refID']=='Lumley2004')['cslData']['page']=='1-19','Lumley page range is 1-19')

bib_indexes=[]
if len(bib_fields)==1:
    for (index,text),expected in zip(bib_fields[0]['texts'].items(),native['bibliography']):
        bib_indexes.append(index)
        check(norm(text)==norm(expected['text']),'Master cached bibliography matches native export: '+expected['refID'])
    check(len(bib_fields[0]['texts'])==25,'Master bibliography contains exactly 25 nonempty paragraphs')
    check(all(effective_numpr(master['paragraphs'][index],master['styles']) is None for index in bib_indexes),'Master bibliography has literal labels only; no inherited or direct automatic numbering')

custom=E.fromstring(master['data']['docProps/custom.xml'])
chunks=sorted((int(p.get('name').rsplit('_',1)[1]),''.join(p.itertext())) for p in custom if p.get('name','').startswith('ZOTERO_PREF_'))
pref_xml=''.join(value for _,value in chunks)
prefs=E.fromstring(pref_xml.encode())
style=prefs.find('style')
check(style.get('id')==native['styleID'],'Master preference style ID matches the installed project CSL')
check(style.get('locale')=='en-US','Master CSL locale is en-US')
check(style.get('hasBibliography')=='1','Master preference retains bibliography support')
check(any(p.get('name')=='fieldType' and p.get('value')=='Field' for p in prefs.findall('prefs/pref')),'Master integration field type is Field')
check([i for i,_ in chunks]==list(range(1,len(chunks)+1)) and all(len(v.encode('utf-16-le'))//2<=255 for _,v in chunks),'Zotero preference chunks are contiguous and <=255 UTF-16 units')

xml_parts={name:data.decode('utf-8',errors='replace') for name,data in submission['data'].items() if name.endswith(('.xml','.rels'))}
all_xml='\n'.join(xml_parts.values())
text='\n'.join(submission['doc'].xpath('.//w:t/text()',namespaces=NS))
check('ZOTERO' not in all_xml and 'zotero.org/users/' not in all_xml,'Submission contains no Zotero field codes, library URIs, or Zotero preferences')
check('docProps/custom.xml' not in submission['data'],'Submission has no custom document-property file')
check(not submission['doc'].xpath('.//w:instrText | .//w:fldChar | .//w:fldSimple',namespaces=NS),'Submission body has no active field functions')
core=E.fromstring(submission['data']['docProps/core.xml'])
for tag in ('creator','lastModifiedBy','identifier','description'):
    values=core.xpath('//*[local-name()=$name]/text()',name=tag)
    check(not any(value.strip() for value in values),'Submission '+tag+' metadata is blank')
app=E.fromstring(submission['data']['docProps/app.xml'])
for tag in ('Company','Manager'):
    check(not any(value.strip() for value in app.xpath('//*[local-name()=$name]/text()',name=tag)),'Submission '+tag+' metadata is blank')
master_core=E.fromstring(master['data']['docProps/core.xml'])
authors=', '.join(master_core.xpath('//*[local-name()="creator"]/text()')).split(', ')
for name in authors:
    if name: check(name.casefold() not in all_xml.casefold(),'Full manuscript-author name absent from submission package: '+name)
private_markers=['benlabeit','benlabeit@gmail.com','529859742','Moorenstraße','Moorenstrasse','Walter Benjamin Programme','Department of Neurology, Medical Faculty','github.com/benlabeit']
for marker in private_markers:
    check(marker.casefold() not in all_xml.casefold(),'Personal/contact/funding marker absent: '+marker)
check(not re.search(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',all_xml),'No email address in submission XML/relationships')
check(not any('comments' in name.lower() or 'people.xml' in name.lower() for name in submission['data']),'No comments/people metadata parts in submission')
check(not submission['doc'].xpath('.//w:ins | .//w:del',namespaces=NS),'No tracked insertion/deletion authors in submission')

submission_texts=[''.join(p.xpath('.//w:t/text()',namespaces=NS)) for p in submission['paragraphs']]
submission_bib=[]
for expected in native['bibliography']:
    matches=[i for i,text in enumerate(submission_texts) if norm(text)==norm(expected['text'])]
    check(len(matches)==1,'Submission reference matches native export exactly once: '+expected['refID'])
    submission_bib.extend(matches)
check(len(submission_bib)==25 and submission_bib==sorted(submission_bib),'Submission reference order and count are 1-25')
check(all(effective_numpr(submission['paragraphs'][index],submission['styles']) is None for index in submission_bib),'Submission bibliography has literal labels only; no inherited or direct automatic numbering')
pattern=r'\[[0-9,\s\u2013-]+\]'
observed=re.findall(pattern,text)
check(observed==[c['plainCitation'] for c in native['citations']],'All 19 flattened bracketed citations retain native content and order')

links=[]
for obj in (master,submission):
    relationships=E.fromstring(obj['data']['word/_rels/document.xml.rels'])
    targets={r.get('Id'):r.get('Target') for r in relationships if r.get('TargetMode')=='External'}
    used_ids=obj['doc'].xpath('.//w:hyperlink/@r:id',namespaces={**NS,'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'})
    used=[targets[rid] for rid in used_ids if rid in targets]
    cdc=['https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2022/adult22csv.zip','https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip','https://www.cdc.gov/nchs/nhis/documentation/2022-nhis.html','https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html']
    check(all(url in used for url in cdc),obj['path'].name+': all four CDC data/documentation hyperlinks have both targets and visible hyperlink elements')
    links=cdc

notes.append('The submission retains an empty built-in Word APA Sources custom XML part and its document GUID. It contains no sources, people, Zotero data, or author identifiers; the coordinating agent accepted this standard nonpersonal Word package component.')
notes.append('Bibliography numbering is literal text (1. through 25.) with no active paragraph or inherited style numbering. There is no double-numbering mechanism.')
notes.append('Published author names in reference entries are retained intentionally and do not identify this manuscript author list as metadata.')
notes.append('Visual rendering and the subsequent Word Refresh are outside this read-only structural check. No DOCX was changed.')

lines=['Dysphagia citation and anonymization structural check', 'Checked at: '+datetime.now(timezone.utc).isoformat(), 'Overall result: '+('PASS' if not errors else 'FAIL'), '']
for obj in (master,submission):
    lines += [obj['path'].name,'SHA-256: '+obj['hash']]
lines += ['', 'Native Zotero update proof:', json.dumps(native.get('nativeMetadataUpdateSummary',{}),ensure_ascii=False), '', 'Summary:',
          '- Master: 19 live citations, one bibliography, 25 real item identities; cached references and embedded metadata checked against the new native export.',
          '- Submission: Zotero content removed, author/contact/funding identifiers and person-related core properties absent; 25 matching references and 19 flattened citations.',
          '- All four CDC links checked as actual DOCX hyperlinks in both documents.',
          '- Explicit and inherited paragraph numbering checked for every bibliography entry.', '', 'Notes:']
lines += ['- '+note for note in notes]
lines += ['', 'Failed checks ('+str(len(errors))+'):']+(['- '+error for error in errors] or ['None.'])
lines += ['', 'Passed checks: '+str(len(passes)), '']+['PASS: '+message for message in passes]
(ROOT/'work/dysphagia/citation_anonymization_check.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'passed':not errors,'checksPassed':len(passes),'failures':errors,'report':'work/dysphagia/citation_anonymization_check.txt'}))
