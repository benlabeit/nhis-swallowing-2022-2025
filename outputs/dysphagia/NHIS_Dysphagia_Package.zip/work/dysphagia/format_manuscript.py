"""Journal adaptation of the verified manuscript, preserving its results and Zotero IDs."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile, ZIP_DEFLATED
import json, re
from lxml import etree as E
from docx import Document
from docx.text.paragraph import Paragraph
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/dysphagia'
OUT.mkdir(parents=True,exist_ok=True)
TITLE='Swallowing Difficulties in Older US Adults by Stroke History in 2022 and 2025'
ABSTRACT='''We compared reported swallowing difficulties among US adults aged 65 years and older in 2022 and 2025, with particular attention to stroke history and response status. We analyzed National Health Interview Survey public-use Sample Adult files using survey weights and design-based variance estimation. The primary outcome was reported swallowing difficulty during the preceding 12 months. Prevalences were standardized to the US 2000 population aged 65 years and older. We estimated between-year differences and the difference between changes in respondents with and without stroke history. Exploratory analyses examined age and sex adjustment and restriction to confirmed self-responses. Valid primary responses were available for 8,485 adults in 2022 and 8,223 in 2025. Age-standardized prevalence was 7.77% versus 8.35%, respectively, a difference of 0.57 percentage points (95% confidence interval [CI], −0.40 to 1.55). Among respondents with stroke history, prevalence was 14.15% versus 20.43%, a difference of 6.27 points (95% CI, 1.08 to 11.47). The additive interaction was 6.05 points (95% CI, 0.77 to 11.33). The stroke-group difference remained positive after age and sex adjustment but decreased to 4.53 points (95% CI, −0.42 to 9.48) with self-response restriction. The overall comparison did not establish a clear prevalence difference. A larger increase was observed among respondents with stroke history, but its magnitude and precision were sensitive to response-status restriction. The 2025 collection interruption and asymmetric response-status classification limit comparability. These findings concern reported symptoms and warrant further surveillance; they do not establish changes in clinically confirmed dysphagia, individual outcomes, or causal effects of stroke over time.'''
KEYWORDS='Swallowing difficulties; Older adults; Stroke; National Health Interview Survey; Prevalence; Population survey'
URLS={y:f'https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/{y}/adult{str(y)[-2:]}csv.zip' for y in (2022,2025)}
DOCURLS={y:f'https://www.cdc.gov/nchs/nhis/documentation/{y}-nhis.html' for y in (2022,2025)}
CAPTIONS={
1:'Reported swallowing difficulties among adults aged 65 years and older in 2022 and 2025. Points indicate survey-weighted prevalence standardized to the US 2000 age distribution; horizontal lines indicate 95% confidence intervals. Circles denote 2022 and squares denote 2025. Event counts and valid-response denominators are unweighted and therefore do not reproduce weighted percentages. The overall group includes unknown stroke status and overlaps both stroke-history subgroups. Estimates account for the survey design. Subgroup comparisons are exploratory. Source: National Health Interview Survey public-use data',
2:'Absolute prevalence differences between 2025 and 2022 by outcome and stroke history. Points indicate age-standardized differences in percentage points; horizontal lines show 95% confidence intervals. The dashed zero line denotes no difference. Substantial difficulty represents the response “a lot”; prolonged symptoms represent at least 180 days during the preceding year. Both secondary outcomes use population denominators, with valid primary-negative responses coded as negative and missing follow-up responses retained as missing. Open circles identify stroke-group contrasts with fewer than ten events in at least one underlying year-by-age cell. Secondary and subgroup analyses are exploratory without multiplicity adjustment. Source: National Health Interview Survey public-use data',
3:'Sensitivity to interview period and missing responses. Points and horizontal lines indicate age-standardized prevalence differences (2025 minus 2022) and 95% confidence intervals. The dashed line denotes no difference. Restriction to interview quarters 1–3 retains annual weights without recalibration. The two extreme scenarios assign all missing primary responses to yes in 2022 and no in 2025, or vice versa. Their intervals represent sampling uncertainty conditional on each assignment and do not form a confidence band across missing-data mechanisms. These exploratory scenarios do not address complete interview nonparticipation or unknown age and stroke status. Source: National Health Interview Survey public-use data',
4:'Stroke-group prevalence differences across analysis methods. Points and horizontal lines show 2025-minus-2022 differences in reported swallowing difficulties and 95% confidence intervals; the dashed line denotes no difference. The primary result is shown by a square and added analyses by circles. Direct estimates use the US 2000 age distribution. Model-adjusted estimates additionally use a fixed 50:50 male:female distribution within age groups. Restriction to confirmed self-responses excludes proxy and ambiguous response status using conservative year-specific classifications and changes the target population. Additional analyses were specified after inspection of the original results; all subgroup and sensitivity comparisons are exploratory without multiplicity adjustment. Source: National Health Interview Survey public-use data'
}
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def font(r,size=11,bold=None):
 r.font.name='Times New Roman';r.font.size=Pt(size);r.font.color.rgb=RGBColor(0,0,0)
 if bold is not None:r.bold=bold
 p=r._r.get_or_add_rPr();f=p.find(qn('w:rFonts'))
 if f is not None:
  for k in list(f.attrib):
   if k.lower().endswith('theme'):del f.attrib[k]
  for a in ('ascii','hAnsi','eastAsia','cs'):f.set(qn('w:'+a),'Times New Roman')
def textof(el):return ''.join(el.itertext()) if False else ''.join(el.xpath('.//w:t/text()',namespaces=NS))
def add_node(doc,el):doc._element.body.insert(len(doc._element.body)-1,deepcopy(el))
def blank_like(src):
 d=Document(src)
 for el in list(d._element.body):
  if el.tag!=qn('w:sectPr'):d._element.body.remove(el)
 return d
def para(doc,text,style=None,before=False):
 p=doc.add_paragraph(text,style)
 if before:p.paragraph_format.page_break_before=True
 return p
def link(p,label,url):
 rid=p.part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
 h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rid)
 r=OxmlElement('w:r');rp=OxmlElement('w:rPr');s=OxmlElement('w:rStyle');s.set(qn('w:val'),'Hyperlink');rp.append(s);r.append(rp)
 t=OxmlElement('w:t');t.text=label;r.append(t);h.append(r);p._p.append(h)
def data_availability(d,citation_para=None):
 para(d,'Data availability','Heading 1')
 p=d.add_paragraph('The original public-use National Health Interview Survey Sample Adult datasets are publicly available from the Centers for Disease Control and Prevention and the National Center for Health Statistics as compressed CSV files: ')
 link(p,'NHIS 2022 (adult22csv.zip)',URLS[2022]);p.add_run(' and ');link(p,'NHIS 2025 (adult25csv.zip)',URLS[2025]);p.add_run('. The unmodified source tables contain 27,651 records and 637 variables for 2022 and 24,215 records and 577 variables for 2025, before analytical exclusions. ')
 link(p,'2022 documentation',DOCURLS[2022]);p.add_run(' and ');link(p,'2025 documentation',DOCURLS[2025]);p.add_run(' provide the questionnaires, codebooks and survey descriptions.')
 if citation_para is not None:
  p.add_run('\u00a0')
  take=False
  for ch in citation_para:
   if ch.tag==qn('w:r') and ch.find(qn('w:fldChar')) is not None:take=True
   if take:p._p.append(deepcopy(ch))
 p=d.add_paragraph('The study materials include original-file checksums, variable mappings, analysis plans, reproducible R code, numerical results, and figure-generation code. The literature search record documents a targeted narrative search, rather than a systematic review.')
def replace_cached(p,newtext):
 # Preserve field delimiters even when Word stored text and fldChar end in
 # the same run. Remove only cached display nodes from each run.
 display_tags={qn('w:'+name) for name in ('t','tab','br','cr','noBreakHyphen','softHyphen')}
 for r in list(p):
  if r.tag!=qn('w:r'):continue
  for child in list(r):
   if child.tag in display_tags:r.remove(child)
  if all(child.tag==qn('w:rPr') for child in r):p.remove(r)
 r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=newtext;r.append(t)
 ends=[x for x in p if x.tag==qn('w:r') and any(f.get(qn('w:fldCharType'))=='end' for f in x.findall(qn('w:fldChar')))]
 if ends:p.insert(p.index(ends[0]),r)
 else:p.append(r)
def configure(d):
 d.core_properties.title=TITLE;d.core_properties.subject='NHIS 2022 and 2025 swallowing difficulties'
 d.core_properties.keywords=KEYWORDS;d.core_properties.last_modified_by=''
 for name in ('Normal','Title','Heading 1','Heading 2','Caption','Bibliography'):
  st=d.styles[name];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
  if name=='Title':st.font.size=Pt(15)
  elif name=='Caption':st.font.size=Pt(10)
  else:st.font.size=Pt(11)
  if name in ('Normal','Heading 1','Heading 2'):st.paragraph_format.line_spacing=1.5
  if name in ('Caption','Bibliography'):st.paragraph_format.line_spacing=1.0
  st.paragraph_format.widow_control=True
 for p in d.paragraphs:
  if p.style.name=='Title':p.paragraph_format.keep_with_next=True
  if p.style.name=='Bibliography':
   p.paragraph_format.space_after=Pt(6)
   p.paragraph_format.keep_together=True
   p.paragraph_format.keep_with_next=False
def replace_native_citations(root,citations):
 # Collect complete complex fields first, including split instruction runs.
 expected={citation['citationID']:citation for citation in citations}
 assert len(expected)==len(citations)==19
 stack=[];completed=[]
 for node in root.iter():
  if node.tag==qn('w:fldChar'):
   kind=node.get(qn('w:fldCharType'))
   if kind=='begin':stack.append({'instructions':[],'texts':[],'phase':'code','separator':None})
   elif kind=='separate':
    assert stack,'Unpaired field separator'
    stack[-1]['phase']='result';stack[-1]['separator']=node
   elif kind=='end':
    assert stack,'Unpaired field end'
    completed.append(stack.pop())
  elif node.tag==qn('w:instrText') and stack:stack[-1]['instructions'].append(node)
  elif node.tag==qn('w:t') and stack and stack[-1]['phase']=='result':stack[-1]['texts'].append(node)
 assert not stack,'Unclosed complex field before native citation replacement'
 seen=[]
 for field in completed:
  code=''.join(node.text or '' for node in field['instructions'])
  if 'ZOTERO_ITEM CSL_CITATION' not in code:continue
  old=json.loads(code.split('CSL_CITATION',1)[1].strip())
  citation_id=old['citationID'];assert citation_id in expected
  fresh=expected[citation_id]
  assert [str(item['id']) for item in old['citationItems']]==[str(item['id']) for item in fresh['citation']['citationItems']]
  # Replace the whole native JSON, including real URIs, current itemData,
  # plainCitation and formattedCitation; do not merge stale metadata.
  field['instructions'][0].text=fresh['fieldCode']
  for node in field['instructions'][1:]:node.getparent().remove(node)
  if field['texts']:
   field['texts'][0].text=fresh['plainCitation']
   for node in field['texts'][1:]:node.getparent().remove(node)
  else:
   separator_run=field['separator'].getparent();parent=separator_run.getparent()
   run=E.Element(qn('w:r'));text=E.SubElement(run,qn('w:t'));text.text=fresh['plainCitation']
   parent.insert(parent.index(separator_run)+1,run)
  seen.append(citation_id)
 assert len(seen)==19 and set(seen)==set(expected),'Native citation coverage differs from manuscript'

def postprocess(path,flat=False,reference_data=None):
 with ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
 root=E.fromstring(parts['word/document.xml'])
 if reference_data:replace_native_citations(root,reference_data['citations'])
 if flat:
  for el in list(root.findall('.//w:instrText',NS))+list(root.findall('.//w:fldChar',NS)):
   par=el.getparent();par.remove(el)
  for el in root.findall('.//w:bookmarkStart',NS)+root.findall('.//w:bookmarkEnd',NS):el.getparent().remove(el)
  parts.pop('docProps/custom.xml',None)
  for name in ('_rels/.rels','[Content_Types].xml'):
   rt=E.fromstring(parts[name])
   for e in list(rt):
    if 'custom-properties' in e.get('Type','') or e.get('PartName')=='/docProps/custom.xml':rt.remove(e)
   parts[name]=E.tostring(rt,xml_declaration=True,encoding='UTF-8',standalone=True)
 elif reference_data:
  rt=E.fromstring(parts['docProps/custom.xml'])
  for property_node in list(rt):
   if property_node.get('name','').startswith('ZOTERO_PREF_'):rt.remove(property_node)
  preferences=reference_data['documentPreferences'];chunks=preferences['customProperties']
  assert ''.join(chunk['value'] for chunk in chunks)==preferences['serialized']
  assert E.fromstring(preferences['serialized'].encode()).find('style').get('id')==reference_data['styleID']
  next_pid=max([int(node.get('pid','1')) for node in rt]+[1])+1
  cpns='http://schemas.openxmlformats.org/officeDocument/2006/custom-properties'
  vtns='http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'
  for i,chunk in enumerate(chunks):
   assert len(chunk['value'].encode('utf-16-le'))//2<=255
   property_node=E.SubElement(rt,'{'+cpns+'}property',{'fmtid':'{D5CDD505-2E9C-101B-9397-08002B2CF9AE}','pid':str(next_pid+i),'name':chunk['name']})
   E.SubElement(property_node,'{'+vtns+'}lpwstr').text=chunk['value']
  parts['docProps/custom.xml']=E.tostring(rt,xml_declaration=True,encoding='UTF-8',standalone=True)
 parts['word/document.xml']=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
 with ZipFile(path,'w',ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)

def main():
 global ABSTRACT
 ABSTRACT=ABSTRACT.replace('with particular attention','with attention')
 assert len(ABSTRACT.split())==250, len(ABSTRACT.split())
 src=ROOT/'outputs/NHIS_Manuscript_Final.docx';base=Document(src);ps=base.paragraphs
 bibdata=json.loads((ROOT/'work/dysphagia/zotero_dysphagia_bibliography.json').read_text(encoding='utf-8-sig'))
 entries=bibdata['bibliography'];assert len(entries)==25
 # Keep source Word tables and all numerical cells exactly unchanged.
 tableblocks=[]
 for i,(start,note) in enumerate(((95,96),(97,98),(99,100))):
  tableblocks.append([deepcopy(ps[start]._p),deepcopy(base.tables[i]._tbl),deepcopy(ps[note]._p)])
 def table(d,n):
  blocks=deepcopy(tableblocks[n-1]);p=Paragraph(blocks[0],d._body);p.style=d.styles['Caption'];p.paragraph_format.page_break_before=False;p.paragraph_format.keep_with_next=True
  for el in blocks:add_node(d,el)
 def figure(d,n):
  p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True;p.paragraph_format.line_spacing=1
  sh=p.add_run().add_picture(str(OUT/f'figures/Fig{n}.png'),width=Inches(6.5));sh._inline.docPr.set('descr',CAPTIONS[n]);sh._inline.docPr.set('title',f'Fig. {n}')
  p=d.add_paragraph(style='Caption');font(p.add_run(f'Fig. {n} '),10,True);p.add_run(CAPTIONS[n]);p.paragraph_format.keep_together=True;p.paragraph_format.space_after=Pt(12)
 def build(identified):
  d=blank_like(src);para(d,TITLE,'Title')
  if identified:
   for i in range(2,11):add_node(d,ps[i]._p)
  p=para(d,'Abstract','Heading 1');p.paragraph_format.page_break_before=identified
  para(d,ABSTRACT)
  p=d.add_paragraph();font(p.add_run('Keywords '),11,True);p.add_run(KEYWORDS)
  for i in range(16,53):
   node=deepcopy(ps[i]._p)
   if i==16:Paragraph(node,d._body).paragraph_format.page_break_before=True
   add_node(d,node)
   p=d.paragraphs[-1]
   if i==31:
    para(d,'Generative AI assistance. ChatGPT (OpenAI) assisted with drafting analysis code, manuscript text and figure layouts, and with formatting. Statistical estimates were produced by the R scripts; numerical validation procedures are described above.')
   if i==33:p.add_run(' Sample inclusion is summarized in Table 1.');table(d,1)
   if i==35:p.add_run(' Primary prevalence estimates are summarized in Table 2 and Fig. 1.');table(d,2);figure(d,1)
   if i==36:p.add_run(' Outcome-specific differences are shown in Fig. 2.');figure(d,2)
   if i==37:p.add_run(' These sensitivity comparisons are shown in Fig. 3.');figure(d,3)
   if i==39:p.add_run(' All four methods are compared in Table 3, with stroke-group contrasts in Fig. 4.');table(d,3);figure(d,4)
  data_availability(d,ps[54]._p)
  if identified:
   for i in range(55,68):add_node(d,ps[i]._p)
  heading=para(d,'References','Heading 1')
  heading.paragraph_format.page_break_before=False
  heading.paragraph_format.keep_with_next=True
  for i,item in enumerate(entries):
   node=deepcopy(ps[69+i]._p);replace_cached(node,item['text'] if isinstance(item,dict) else item);add_node(d,node)
  # Word stores the bibliography terminator in the following otherwise empty paragraph.
  for r in ps[94]._p:
   if r.tag==qn('w:r') and any(f.get(qn('w:fldCharType'))=='end' for f in r.findall(qn('w:fldChar'))):
    d.paragraphs[-1]._p.append(deepcopy(r))
  configure(d)
  if not identified:
   d.core_properties.author='';d.core_properties.last_modified_by='';d.core_properties.comments='';d.core_properties.identifier=''
  name='NHIS_Dysphagia_Zotero_Master.docx' if identified else 'NHIS_Dysphagia_Manuscript.docx'
  path=OUT/name;d.save(path);postprocess(path,flat=not identified,reference_data=bibdata)
  check=Document(path)
  (OUT/path.with_suffix('.txt').name).write_text('\n\n'.join(p.text for p in check.paragraphs),encoding='utf-8')
  return path
 paths=[build(False),build(True)]
 auth=blank_like(src);para(auth,TITLE,'Title')
 for i in range(2,11):add_node(auth,ps[i]._p)
 for i in range(55,68):add_node(auth,ps[i]._p)
 data_availability(auth)
 configure(auth);a=OUT/'NHIS_Dysphagia_Author_Information.docx';auth.save(a);postprocess(a,flat=True);paths.append(a)
 stats={'title':TITLE,'title_words':len(TITLE.split()),'abstract_words':len(ABSTRACT.split()),'keywords':len(KEYWORDS.split(';')),'tables':3,'figures':4,'references':25,'files':[str(p) for p in paths]}
 for p in paths:
  with ZipFile(p) as z:
   root=E.fromstring(z.read('word/document.xml'));codes=root.xpath('.//w:instrText/text()',namespaces=NS)
   delimiter_counts={kind:len(root.xpath('.//w:fldChar[@w:fldCharType="'+kind+'"]',namespaces=NS)) for kind in ('begin','separate','end')}
   assert len(set(delimiter_counts.values()))==1,delimiter_counts
   stats[p.name]={'zotero_citations':sum('ZOTERO_ITEM' in x for x in codes),'zotero_bibliographies':sum('ZOTERO_BIBL ' in x for x in codes),'active_body_fields':len(codes),'tables':len(Document(p).tables)}
 assert stats[paths[0].name]['active_body_fields']==0
 assert stats[paths[1].name]['zotero_citations']==19
 assert stats[paths[1].name]['zotero_bibliographies']==1
 for i,t in enumerate(Document(paths[0]).tables):
  assert [[c.text for c in r.cells] for r in t.rows]==[[c.text for c in r.cells] for r in base.tables[i].rows]
 (ROOT/'work/dysphagia/format_validation.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
