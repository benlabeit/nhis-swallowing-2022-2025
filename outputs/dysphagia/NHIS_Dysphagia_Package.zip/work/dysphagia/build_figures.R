# Run from the project root: Rscript work/dysphagia/build_figures.R
# Journal-size redraws from saved estimates. No statistical analysis is rerun.
if (.Platform$OS.type == 'windows') Sys.setlocale('LC_CTYPE', 'English_United States.utf8')
.libPaths(c('work/Rlib', .libPaths()))
library(grid)
out <- 'outputs/dysphagia/figures'
dir.create(out, recursive=TRUE, showWarnings=FALSE)
main <- read.delim('outputs/standardized_results.tsv', check.names=FALSE)
counts <- read.delim('outputs/cell_counts.tsv', check.names=FALSE)
comparisons <- read.delim('outputs/extensions/primary_comparison_all_methods.tsv', check.names=FALSE)
stopifnot(!anyDuplicated(main[c('analysis','group','outcome','estimate_type')]))

row <- function(group, outcome='any', kind='difference_2025_minus_2022', analysis='main') {
  z <- main[main$group==group & main$outcome==outcome & main$estimate_type==kind & main$analysis==analysis,]
  stopifnot(nrow(z)==1, all(is.finite(as.matrix(z[c('estimate','lcl','ucl')]))),
            z$lcl<=z$estimate, z$estimate<=z$ucl)
  z
}
methods <- c('main','age_sex_adjusted','self_direct_age_standardized','self_age_sex_adjusted')
robustness <- comparisons[comparisons$group=='stroke' & comparisons$outcome=='any' & comparisons$estimate_type=='difference_2025_minus_2022',]
robustness <- robustness[match(methods, robustness$analysis),]
stopifnot(identical(robustness$analysis, methods), nrow(robustness)==4,
          all(is.finite(as.matrix(robustness[c('estimate','lcl','ucl')]))),
          all(robustness$lcl<=robustness$estimate & robustness$estimate<=robustness$ucl))
stopifnot(max(abs(as.numeric(robustness[1,c('estimate','lcl','ucl')]) -
                 as.numeric(row('stroke')[1,c('estimate','lcl','ucl')]))) < 1e-12)

palette <- list(ink='#182F40', muted='#4D5B64', grid='#DCE2E6', blue='#0072B2',
                orange='#D55E00', grey='#6E7C85', zero='#6A7882')
width_mm <- 165
heights_mm <- c(115, 142, 133, 100)
left <- .025; indent <- .045; forest_left <- .405; forest_right <- .720; values_right <- .985
fmt <- function(x, sign=FALSE) gsub('-', '\u2212', sprintf(if(sign) '%+.2f' else '%.2f', x), fixed=TRUE)
interval <- function(z, difference=TRUE) paste0(fmt(100*z$estimate,difference), ' [', fmt(100*z$lcl), ', ', fmt(100*z$ucl), ']')

text <- function(label, x, y, size=9, col=palette$ink, bold=FALSE, just='left', xmax=NULL, xmin=NULL) {
  gp <- gpar(fontsize=size, fontfamily='Arial', col=col, fontface=if(bold)'bold' else 'plain', lineheight=1.05)
  g <- textGrob(label, x=x, y=y, just=just, gp=gp)
  # Check actual rendered string width against the assigned column, on every device.
  w <- convertWidth(grobWidth(g), 'npc', valueOnly=TRUE)
  lo <- x - if(just=='right') w else if(just=='centre') w/2 else 0
  hi <- x + if(just=='left') w else if(just=='centre') w/2 else 0
  stopifnot(lo >= -.001, hi <= 1.001)
  if(!is.null(xmax)) stopifnot(hi <= xmax)
  if(!is.null(xmin)) stopifnot(lo >= xmin)
  grid.draw(g)
}
line <- function(x0,y0,x1,y1,col=palette$grid,width=.65,type=1) {
  grid.lines(c(x0,x1),c(y0,y1),gp=gpar(col=col,lwd=width,lty=type))
}
page <- function(left_header, value_header) {
  grid.newpage()
  grid.rect(gp=gpar(fill='white',col=NA))
  text(left_header,left,.955,8.5,col=palette$muted,xmax=forest_left-.01)
  text(value_header,values_right,.955,8.5,col=palette$muted,just='right',xmin=forest_right+.015)
  line(left,.920,values_right,.920,width=.7)
}
axis <- function(limits,ticks,bottom,top,zero=FALSE) {
  X <- function(value) forest_left + (value-limits[1])/diff(limits)*(forest_right-forest_left)
  attr(X,'limits') <- limits
  for(value in ticks) {
    line(X(value),bottom,X(value),top,
         if(value==0 && zero)palette$zero else palette$grid,
         if(value==0 && zero)1 else .55,
         if(value==0 && zero)2 else 1)
    text(gsub('-','\u2212',as.character(value),fixed=TRUE), X(value), bottom-.032,8.5,
         col=palette$muted,just='centre')
  }
  line(forest_left,bottom,forest_right,bottom,palette$muted,.65)
  X
}
point <- function(z,y,X,col=palette$blue,pch=16,open=FALSE) {
  limits <- attr(X,'limits')
  stopifnot(all(100*c(z$lcl,z$ucl)>=limits[1]),all(100*c(z$lcl,z$ucl)<=limits[2]))
  line(X(100*z$lcl),y,X(100*z$ucl),y,col,1.35)
  for(value in c(z$lcl,z$ucl)) line(X(100*value),y-.006,X(100*value),y+.006,col,.9)
  grid.points(unit(X(100*z$estimate),'npc'),unit(y,'npc'),pch=if(open)21 else pch,size=unit(2.0,'mm'),
              gp=gpar(col=col,fill=if(open)'white' else col,lwd=1.05))
}
group_names <- c('All adults aged 65+','With a history of stroke','Without a history of stroke')
group_ids <- c('all','stroke','no_stroke')
selected <- list()

fig1 <- function() {
  page('Year; events / valid responses','Prevalence, % [95% CI]')
  X <- axis(c(0,30), seq(0,30,5), .120,.875)
  for(i in 1:3) {
    h <- c(.860,.590,.320)[i]
    text(group_names[i],left,h,9.5,bold=TRUE,xmax=forest_left-.01)
    for(j in 1:2) {
      yr <- c(2022,2025)[j]; y <- h-c(.065,.145)[j]
      z <- row(group_ids[i],kind=paste0('standardized_',yr))
      ct <- counts[counts$year==yr & counts$group==group_ids[i] & counts$agegroup=='all' & counts$outcome=='any',]
      stopifnot(nrow(ct)==1,z$n==ct$valid,z$events==ct$yes)
      color <- if(j==1)palette$blue else palette$orange
      text(paste0(yr,'   ',z$events,' / ',format(z$n,big.mark=',',scientific=FALSE,trim=TRUE)),
           indent,y,9,col=color,xmax=forest_left-.01)
      point(z,y,X,color,if(j==1)16 else 15)
      text(interval(z,FALSE),values_right,y,9,just='right',xmin=forest_right+.015)
    }
  }
  text('Age-standardized prevalence (%)',.635,.035,9,just='centre')
}
fig2 <- function() {
  page('Population / outcome','Difference [95% CI]')
  X <- axis(c(-4,12),seq(-4,12,4),.100,.875,zero=TRUE)
  labels <- c('Swallowing problems','Substantial difficulties','Problems for \u2265180 days')
  for(i in 1:3) {
    h <- c(.860,.605,.350)[i]
    text(group_names[i],left,h,9.5,bold=TRUE,xmax=forest_left-.01)
    for(j in 1:3) {
      y <- h-c(.055,.120,.185)[j]
      z <- row(group_ids[i],c('any','severe','long')[j])
      text(labels[j],indent,y,8.8,bold=j==1,xmax=forest_left-.01)
      point(z,y,X,if(j==1)palette$blue else palette$grey,open=z$fragile)
      text(interval(z),values_right,y,9,just='right',xmin=forest_right+.015)
    }
  }
  text('Prevalence difference (percentage points)',.635,.026,9,just='centre')
}
fig3 <- function() {
  page('Population / analysis assumption','Difference [95% CI]')
  X <- axis(c(-5,16),c(-5,0,5,10,15),.115,.875,zero=TRUE)
  labels <- c('Main analysis: valid responses','Quarters 1\u20133 only',
              'Missing responses:\n2022 yes / 2025 no',
              'Missing responses:\n2022 no / 2025 yes')
  for(i in 1:2) {
    h <- c(.860,.480)[i]
    text(group_names[i],left,h,9.5,bold=TRUE,xmax=forest_left-.01)
    for(j in 1:4) {
      y <- h-c(.065,.140,.215,.290)[j]
      z <- row(group_ids[i],c('any','any','opposite_low','opposite_high')[j],
               analysis=c('main','Q1_Q3','missing_bounds','missing_bounds')[j])
      text(labels[j],indent,y,8.5,bold=j==1,xmax=forest_left-.01)
      point(z,y,X,if(j<=2)palette$blue else palette$grey,if(j<=2)16 else 18)
      text(interval(z),values_right,y,9,just='right',xmin=forest_right+.015)
    }
  }
  text('Prevalence difference (percentage points)',.635,.028,9,just='centre')
}
fig4 <- function() {
  page('Method / included responses','Difference [95% CI]')
  X <- axis(c(-2,12),seq(-2,12,2),.130,.865,zero=TRUE)
  labels <- c('Direct age standardization','Age and sex adjustment',
              'Direct age standardization','Age and sex adjustment')
  subs <- c('All valid responses','All valid responses',
            'Confirmed self-responses only','Confirmed self-responses only')
  yy <- c(.800,.610,.420,.230)
  for(i in 1:4) {
    y <- yy[i]; z <- robustness[i,]
    text(labels[i],left,y+.024,9,bold=i==1,xmax=forest_left-.01)
    text(subs[i],left,y-.028,8.3,col=palette$muted,xmax=forest_left-.01)
    point(z,y,X,if(i<=2)palette$blue else palette$grey,if(i==1)15 else 16)
    text(interval(z),values_right,y,9,just='right',xmin=forest_right+.015)
  }
  text('Prevalence difference (percentage points)',.635,.035,9,just='centre')
}
figures <- list(fig1,fig2,fig3,fig4)
for(i in 1:4) {
  file <- file.path(out,paste0('Fig',i))
  w <- width_mm/25.4; h <- heights_mm[i]/25.4
  png(paste0(file,'.png'),width=w,height=h,units='in',res=600,type='cairo',bg='white')
  figures[[i]]();dev.off()
  svg(paste0(file,'.svg'),width=w,height=h,family='Arial',bg='white')
  figures[[i]]();dev.off()
  cairo_pdf(paste0(file,'.pdf'),width=w,height=h,family='Arial',bg='white')
  figures[[i]]();dev.off()
  cairo_ps(paste0(file,'.eps'),width=w,height=h,family='Arial',bg='white',onefile=FALSE)
  figures[[i]]();dev.off()
}

# Export the exact plotted source rows; there is no re-estimation or rounding here.
fig1_rows <- do.call(rbind,lapply(group_ids,function(g)do.call(rbind,lapply(c(2022,2025),function(y)row(g,kind=paste0('standardized_',y))))))
fig2_rows <- do.call(rbind,lapply(group_ids,function(g)do.call(rbind,lapply(c('any','severe','long'),function(o)row(g,o)))))
fig3_rows <- do.call(rbind,lapply(group_ids[1:2],function(g)do.call(rbind,lapply(1:4,function(j)row(g,c('any','any','opposite_low','opposite_high')[j],analysis=c('main','Q1_Q3','missing_bounds','missing_bounds')[j])))))
plotted <- list(fig1_rows,fig2_rows,fig3_rows,robustness)
for(i in 1:4)write.table(plotted[[i]],file.path(out,paste0('Fig',i,'_values.tsv')),sep='\t',row.names=FALSE)
writeLines(c('Journal figure redraw validation',
             'Four figures, 165 mm wide; heights 115, 142, 133 and 100 mm.',
             'PNG: 600 dpi. PDF/SVG/EPS: vector. Arial; labels 8.3-9.5 pt.',
             'No embedded figure number, title, subtitle, caption or methods/source footnote.',
             'Column headings, axis labels, group labels and estimates remain inside the artwork.',
             'All plotted records are copied from saved results, not re-estimated.',
             'Every point/interval is finite and contained in the axis range.',
             'Actual text widths checked for page and column containment on all four devices.',
             'Figure 1 event/denominator counts match the existing count table.',
             'Figure 4 primary contrast matches the original analysis within 1e-12.',
             paste('Input MD5:',paste(names(tools::md5sum(c('outputs/standardized_results.tsv','outputs/cell_counts.tsv','outputs/extensions/primary_comparison_all_methods.tsv'))),
               unname(tools::md5sum(c('outputs/standardized_results.tsv','outputs/cell_counts.tsv','outputs/extensions/primary_comparison_all_methods.tsv'))),collapse='; '))),
           file.path(out,'validation.txt'))
capture.output(sessionInfo(),file=file.path(out,'software.txt'))
writeLines(c('Journal artwork - four English figures',
             'Use Fig1.png through Fig4.png in Word at a width of 165 mm.',
             'Use Fig1.pdf through Fig4.pdf, or the corresponding EPS files, for vector submission.',
             'PNG images are 600 dpi; SVG copies are also provided.',
             'Do not add titles or figure captions to the artwork; supply them separately in the manuscript.',
             'Captions must explain the symbols, confidence intervals, exploratory analyses and source limitations.',
             'Fig2 uses the label Substantial difficulties for the existing severe outcome; the numeric endpoint is unchanged.',
             'Reproduce from project root: Rscript work/dysphagia/build_figures.R',
             'Original outputs/figures files remain unchanged.'),file.path(out,'README.txt'))
