# NHIS Dysphagia journal package

The current journal files are in `outputs/dysphagia/`:

- `NHIS_Dysphagia_Manuscript.docx`: anonymized review manuscript; references are static Zotero-generated text.
- `NHIS_Dysphagia_Zotero_Master.docx`: identified working master with live Zotero citations and bibliography.
- `NHIS_Dysphagia_Author_Information.docx`: identified author details and declarations for the submission portal.
- `figures/Fig1` through `Fig4`: PDF, EPS and SVG vector artwork, 600-dpi PNGs, plotted values and validation records. Figure captions are in the manuscript.
- `nhis-dysphagia-basic-brackets.csl`: the separate project citation style.

The archive also contains identified working materials, author provenance and an earlier identified source manuscript. It is a project handover archive, not an anonymous reviewer upload. Use only the designated anonymous DOCX as the review manuscript and follow the journal's portal fields for author information. No submission is made by any included script. Read `outputs/dysphagia/README.txt` and `outputs/author_checks.txt` before submission.

## Original data

`outputs/data_original/adult22.csv` and `adult25.csv` are the complete unchanged source tables, before analytical exclusions. They contain 27,651 rows and 637 columns (2022), and 24,215 rows and 577 columns (2025), excluding the header row. The unchanged downloaded CDC ZIP files are stored once, under `work/raw/`. The original-data manifest records SHA-256 hashes, exact file sizes, table dimensions and official download URLs. No original CSV or ZIP is modified by the packaging process.

- https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2022/adult22csv.zip
- https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/2025/adult25csv.zip
- https://www.cdc.gov/nchs/nhis/documentation/2022-nhis.html
- https://www.cdc.gov/nchs/nhis/documentation/2025-nhis.html

## Scope and the complete analysis project

This journal package contains the existing estimates and the inputs needed for the supplied journal figure and document-formatting helpers. It does not contain the complete statistical-analysis pipeline or the official codebook/Survey Description PDFs and does not claim standalone reproduction of the statistical analyses. The previously completed full analysis project, including the original R analysis scripts and documentation, is maintained in the existing private GitHub repository:

https://github.com/benlabeit/nhis-swallowing-2022-2025

Repository access requires authorization. The identified repository is not linked from the anonymous manuscript. The complete local analysis handover was delivered separately as `NHIS_Research_Package.zip`.

`outputs/NHIS_Manuscript_Final.docx` is the earlier pre-journal source required by `format_manuscript.py`. It is retained solely for reproduction of the journal adaptation; the user-facing current journal documents are the files in `outputs/dysphagia/`.

## Reproduce journal artwork and document formatting

Extract the archive to a new working folder and run commands from that folder. Regeneration overwrites generated files in that extracted copy. Python needs `python-docx`, `lxml`, `Pillow`, and `pypdf`; R needs its standard `grid` and graphics libraries, Cairo support, and Arial fonts. The original artwork used R 4.6.0; software details are in `outputs/dysphagia/figures/software.txt`.

```
Rscript work/dysphagia/build_figures.R
python work/dysphagia/check_figures.py
python work/dysphagia/format_manuscript.py
python work/dysphagia/check_citations_anonymization.py
```

The figure script reads exactly three included aggregate tables: `outputs/standardized_results.tsv`, `outputs/cell_counts.tsv`, and `outputs/extensions/primary_comparison_all_methods.tsv`. It does not re-estimate survey models. The document formatter reads the earlier source DOCX, the four current figure PNGs, and `work/dysphagia/zotero_dysphagia_bibliography.json`; it retains the source numerical tables and uses the saved native Zotero citation export.

The formatter creates the pre-refresh working documents, not a byte-identical copy of the Word-saved final master. Open the regenerated master in Microsoft Word with Zotero's Word add-in, install the supplied CSL, perform native Zotero Refresh, save, and close the master in Word. Then run:

```
python work/dysphagia/format_master_bibliography_after_refresh.py
```

That helper requires a successfully saved native Refresh and adjusts only the master's bibliography style and 25 reference paragraphs to 11-point type, single spacing and intact entries, with References beginning on a new page. The final manual step is to export from Word and visually inspect every page, including figure/table captions and bibliography entry breaks. Native Refresh may replace direct bibliography paragraph formatting, so the final layout correction follows the last Refresh. Keep the identified master separate from the anonymized review copy. Recheck both documents after any substantive edit or new refresh. The supplied audit reports document the original run only and are not proof of checks on a later regeneration.

## Zotero and literature

`outputs/literature/` contains the earlier targeted narrative search record, evidence table, reference metadata and native library exports. The authoritative journal-specific rendering and 25-item metadata export is `work/dysphagia/zotero_dysphagia_bibliography.json`; its companion citation export contains 19 citation clusters. The offline preview files and rendering screenshots are deliberately omitted.

`work/dysphagia/apply_dysphagia_in_zotero.js` is a Zotero Run JavaScript helper for the original 25-item library. It is not a Node.js program. Its stored absolute project paths must be updated before reuse. It verifies original item identities before modifying the permitted metadata fields, installs the separate project CSL, and writes native exports. On a different Zotero library, first import the supplied reference metadata using `work/zotero_import_export.js`, then explicitly remap and verify item IDs/keys in the journal update plan; do not reuse the original library IDs blindly. The saved native export allows figure/document inspection without accessing the original account.

The literature search is targeted and narrative, not systematic. The original metadata audit predates native execution; final checks and native export proof supersede its historical work-status notes.

## Package integrity and rights

`journal_package_manifest.tsv` lists the size and SHA-256 of every packaged source file and generated README/requirements file. It excludes itself. The packaging script verifies original-data files against their existing source manifest and checks ZIP integrity. It does not rerun scientific analyses, refresh Zotero, or change source files.

No new license for the manuscript or project materials is asserted. CDC data-use conditions and the license attribution already present in the supplied CSL remain applicable. No official endorsement is implied.
