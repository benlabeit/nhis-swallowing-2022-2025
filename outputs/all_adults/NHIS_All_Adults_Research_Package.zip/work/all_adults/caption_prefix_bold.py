"""Apply bold only to figure-caption labels without rewriting the DOCX package.

Only word/document.xml and, when necessary, word/styles.xml can change.
All textual content, field instructions, Zotero preferences and other parts are
verified unchanged. Figure labels include Fig. 1 through Fig. 4 and Fig. S1.
"""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile
from lxml import etree as E
import json, re, hashlib

NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
q=lambda name:'{'+NS['w']+'}'+name

def bold_run(run, enabled):
    rpr=run.find('w:rPr',NS)
    if rpr is None:
        rpr=E.Element(q('rPr'));run.insert(0,rpr)
    for name in ('b','bCs'):
        node=rpr.find('w:'+name,NS)
        if node is None:node=E.SubElement(rpr,q(name))
        node.set(q('val'),'1' if enabled else '0')

def plain_run(template, text):
    run=deepcopy(template)
    for child in list(run):
        if child.tag!=q('rPr'):run.remove(child)
    node=E.SubElement(run,q('t'))
    node.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
    node.text=text
    return run

def apply_caption_prefix_bold(path):
    path=Path(path)
    with ZipFile(path) as archive:
        infos=archive.infolist()
        parts={item.filename:archive.read(item.filename) for item in infos}
    hashes={name:hashlib.sha256(data).hexdigest() for name,data in parts.items()}
    document=E.fromstring(parts['word/document.xml'])
    styles=E.fromstring(parts['word/styles.xml'])
    paragraphs=document.findall('.//w:p',NS)
    text_before=[''.join(p.xpath('.//w:t/text()',namespaces=NS)) for p in paragraphs]
    codes_before=document.xpath('.//w:instrText/text()',namespaces=NS)
    captions=[]
    for paragraph,text in zip(paragraphs,text_before):
        match=re.match(r'^(Fig\. (?:[1-4]|S1))(?=\s)',text)
        if not match:continue
        boundary=match.end()
        offset=0
        for run in list(paragraph):
            if run.tag!=q('r'):continue
            assert all(child.tag in (q('rPr'),q('t')) for child in run), 'Unexpected caption run content'
            current=''.join(run.xpath('./w:t/text()',namespaces=NS))
            end=offset+len(current)
            if offset<boundary<end:
                left=plain_run(run,current[:boundary-offset])
                right=plain_run(run,current[boundary-offset:])
                bold_run(left,True);bold_run(right,False)
                index=paragraph.index(run)
                paragraph.remove(run);paragraph.insert(index,left);paragraph.insert(index+1,right)
            else:
                bold_run(run,end<=boundary and bool(current))
            offset=end
        assert offset==len(text)
        captions.append(match.group(1))
    assert sorted(captions)==['Fig. 1','Fig. 2','Fig. 3','Fig. 4','Fig. S1'],captions
    matched_styles=[]
    for style in styles.findall('w:style',NS):
        name=style.find('w:name',NS)
        if name is not None and name.get(q('val'),'').lower()=='caption':
            rpr=style.find('w:rPr',NS)
            if rpr is None:rpr=E.SubElement(style,q('rPr'))
            for bold in ('b','bCs'):
                node=rpr.find('w:'+bold,NS)
                if node is None:node=E.SubElement(rpr,q(bold))
                node.set(q('val'),'0')
            matched_styles.append(style.get(q('styleId')))
    assert len(matched_styles)==1,matched_styles
    assert text_before==[''.join(p.xpath('.//w:t/text()',namespaces=NS)) for p in paragraphs]
    assert codes_before==document.xpath('.//w:instrText/text()',namespaces=NS)
    parts['word/document.xml']=E.tostring(document,xml_declaration=True,encoding='UTF-8',standalone=True)
    parts['word/styles.xml']=E.tostring(styles,xml_declaration=True,encoding='UTF-8',standalone=True)
    changed=[name for name,blob in parts.items() if hashlib.sha256(blob).hexdigest()!=hashes[name]]
    assert set(changed).issubset({'word/document.xml','word/styles.xml'}),changed
    temp=path.with_name(path.stem+'.caption-tmp.docx')
    with ZipFile(temp,'w') as archive:
        for info in infos:archive.writestr(info,parts[info.filename])
    temp.replace(path)
    return {'file':path.name,'bold_prefixes':captions,'changed_parts':changed,
            'all_text_and_field_instructions_unchanged':True,
            'all_other_parts_including_metadata_and_zotero_preferences_unchanged':True}

if __name__=='__main__':
    root=Path(__file__).resolve().parents[2]
    results=[apply_caption_prefix_bold(root/'outputs/all_adults/manuscript'/name) for name in
             ('NHIS_All_Adults_Manuscript.docx','NHIS_All_Adults_Zotero_Master.docx')]
    (root/'work/all_adults/caption_prefix_validation.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))
