# Independent arithmetic and ultimate-cluster Taylor validation.
# Does not use survey estimators or the main script's functions.
d <- readRDS('work/prepared.rds')
ages <- c('18-44','45-64','65-74','75-84','85+')
q <- c(108151050,60991658,18135514,12314793,4259173)/203852188
d$ag <- cut(d$AGEP_A,c(17,44,64,74,84,85),labels=ages)
keys <- unique(d[c('PSTRAT','PPSU')])
keys$key <- paste(keys$PSTRAT,keys$PPSU,sep=':')
rawkey <- paste(d$PSTRAT,d$PPSU,sep=':')
manual <- list(); k <- 0
all_influences <- list()
for (gr in c('all','stroke','no_stroke')) {
  infl <- matrix(0,nrow(d),2); est <- c(0,0)
  for (j in 1:2) {
    yr <- c(2022,2025)[j]
    for(a in seq_along(ages)) {
      ix <- which(d$SRVY_YR==yr & d$ag==ages[a] & !is.na(d$any) &
                  (gr=='all' | (!is.na(d$stroke) & d$stroke==as.integer(gr=='stroke'))))
      w <- d$WTFA_A[ix]; y <- d$any[ix]; p <- sum(w*y)/sum(w)
      est[j] <- est[j]+q[a]*p
      infl[ix,j] <- q[a]*w*(y-p)/sum(w)
    }
  }
  all_influences[[gr]] <- infl
  ci <- rowsum(infl,rawkey,reorder=FALSE)
  ci <- ci[match(keys$key,rownames(ci)),,drop=FALSE]
  V <- matrix(0,2,2)
  for (h in unique(keys$PSTRAT)) {
    x <- ci[keys$PSTRAT==h,,drop=FALSE]; m <- nrow(x)
    stopifnot(m>1)
    cen <- sweep(x,2,colMeans(x),'-')
    V <- V+m/(m-1)*crossprod(cen)
  }
  k<-k+1;manual[[k]] <- data.frame(group=gr,estimate_type=c('prevalence_2022','prevalence_2025','difference_2025_minus_2022'),
      estimate=c(est,est[2]-est[1]),se=sqrt(c(diag(V),sum(V*c(1,-1,-1,1)))))
}
m <- do.call(rbind,manual)
r <- read.delim('outputs/all_adults/standardized_results.tsv')
r <- subset(r,outcome=='any' & group %in% c('all','stroke','no_stroke'))
r$estimate_type <- sub('^standardized_','prevalence_',r$estimate_type)
write.table(m,'work/all_adults/independent_primary_values.tsv',sep='\t',row.names=FALSE)
checks <- list()
for(i in seq_len(nrow(m))) {
  z <- r[r$group==m$group[i] & r$estimate_type==m$estimate_type[i],]
  if(nrow(z)!=1)stop('Result schema mismatch: ',m$group[i],' ',m$estimate_type[i],'; available:',paste(r$estimate_type,collapse=','))
  checks[[i]] <- data.frame(group=m$group[i],contrast=m$estimate_type[i],
     estimate_abs_error=abs(z$estimate-m$estimate[i]),se_abs_error=abs(z$se-m$se[i]))
}
ch <- do.call(rbind,checks)
stopifnot(max(ch$estimate_abs_error)<1e-10,max(ch$se_abs_error)<1e-10)
write.table(ch,'outputs/all_adults/Independent_Primary_Validation.tsv',sep='\t',row.names=FALSE)
writeLines(c('PASS: Independent weighted ratio arithmetic and explicit PSU-level Taylor covariance match all nine primary population/stroke/no-stroke levels and changes.',
  'No survey-package functions or functions from the main analysis were used in this check.',
  paste('Maximum estimate error:',max(ch$estimate_abs_error)),paste('Maximum standard-error error:',max(ch$se_abs_error)),
  'Full-sample PSU structure and cross-year covariance were retained; tolerance=1e-10.'),
  'outputs/all_adults/Independent_Primary_Validation.txt')
print(ch)
