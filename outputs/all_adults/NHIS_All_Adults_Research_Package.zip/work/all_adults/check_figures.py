"""Technical validation of the four journal redraws; no data analysis."""
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from PIL import Image
from pypdf import PdfReader

root = Path(__file__).resolve().parents[2]
folder = root / 'outputs/all_adults/figures'
checks = []
for number in ['1', '2', '3', '4', 'S1']:
    prefix = folder / f'Fig{number}'
    pdf = PdfReader(prefix.with_suffix('.pdf'))
    assert len(pdf.pages) == 1
    page = pdf.pages[0]
    sizes = []
    def visit(text, cm, tm, font, size):
        if text.strip():
            # Cairo sets Tf=1 and the actual point size in the text matrix.
            sizes.append(size * math.hypot(tm[2], tm[3]) * math.hypot(cm[0], cm[1]))
    text = page.extract_text(visitor_text=visit)
    assert not re.search(r'NHIS 2022 / 2025|FIGURE [1-4]|Source:|authors.? calculations', text)
    assert min(sizes) >= 8 and max(sizes) <= 12
    fonts = []
    for reference in page['/Resources']['/Font'].values():
        font = reference.get_object()
        embedded = False
        for descendant in font.get('/DescendantFonts', [font]):
            descriptor = descendant.get_object().get('/FontDescriptor')
            if descriptor:
                embedded = any(key in descriptor.get_object() for key in ['/FontFile', '/FontFile2', '/FontFile3'])
        fonts.append({'name': str(font.get('/BaseFont')), 'embedded': embedded})
    assert all(font['embedded'] for font in fonts)
    assert not list(page.images)
    with Image.open(prefix.with_suffix('.png')) as raster:
        pixels = raster.size
        dpi = raster.info.get('dpi')
    assert all(abs(value - 600) < .1 for value in dpi)
    mm = [float(value) * 25.4 / 72 for value in [page.mediabox.width, page.mediabox.height]]
    assert abs(mm[0] - 165) < .5
    eps = prefix.with_suffix('.eps').read_text(encoding='latin-1')
    assert eps.splitlines()[0] == '%!PS-Adobe-3.0 EPSF-3.0'
    eps_fonts = re.findall(r'^%%BeginResource: font (.+)$', eps, re.M)
    assert eps_fonts
    with (folder / f'Fig{number}_values.tsv').open(encoding='utf-8') as stream:
        source_rows = list(csv.DictReader(stream, delimiter='\t'))
    expected_rows = {'1': 6, '2': 9, '3': 10, '4': 10, 'S1': 8}[number]
    assert len(source_rows) == expected_rows
    checks.append({'figure': number, 'source_rows': len(source_rows),
                   'png_pixels': pixels, 'png_dpi': dpi,
                   'pdf_mm': [round(value, 2) for value in mm],
                   'pdf_font_sizes_pt': [min(sizes), max(sizes)],
                   'pdf_fonts': fonts, 'pdf_raster_images': 0,
                   'eps_embedded_font_resources': eps_fonts,
                   'eps_header': eps.splitlines()[0]})

(folder / 'technical_checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
with (folder / 'artwork_manifest.tsv').open('w', encoding='utf-8', newline='') as stream:
    writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
    writer.writerow(['file', 'bytes', 'sha256'])
    for number in ['1', '2', '3', '4', 'S1']:
        for suffix in ('png', 'pdf', 'svg', 'eps'):
            path = folder / f'Fig{number}.{suffix}'
            writer.writerow([path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest()])
print(json.dumps(checks, indent=2))
