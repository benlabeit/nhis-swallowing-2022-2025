"""Final caption correction and bibliography layout after native Zotero refresh."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import importlib.util
from docx import Document
from caption_prefix_bold import apply_caption_prefix_bold

ROOT=Path(__file__).resolve().parents[2]
OLD='Open markers flag direct estimates with sparse contributing age cells; model-based margins borrow information across age cells and remain subject to model assumptions.'
NEW='Direct estimates remain sensitive to sparse contributing age cells; model-based margins borrow information across age cells and remain subject to model assumptions.'
for relative in ('work/all_adults/manuscript_content.json','work/all_adults/fill_manuscript_content.py',
                 'work/all_adults/figure_captions.json','outputs/all_adults/figures/captions.json'):
    p=ROOT/relative
    text=p.read_text(encoding='utf-8')
    p.write_text(text.replace(OLD,NEW),encoding='utf-8')
for name in ('NHIS_All_Adults_Manuscript','NHIS_All_Adults_Zotero_Master'):
    p=ROOT/'outputs/all_adults/manuscript'/f'{name}.docx'
    with ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
    before=parts['word/document.xml']
    after=before.replace(OLD.encode(),NEW.encode())
    assert before!=after or NEW.encode() in before
    parts['word/document.xml']=after
    with ZipFile(p,'w',ZIP_DEFLATED) as z:
        for n,b in parts.items():z.writestr(n,b)
    p.with_suffix('.txt').write_text('\n\n'.join(q.text for q in Document(p).paragraphs),encoding='utf-8')
spec=importlib.util.spec_from_file_location('bib_layout',ROOT/'work/dysphagia/format_master_bibliography_after_refresh.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MASTER=ROOT/'outputs/all_adults/manuscript/NHIS_All_Adults_Zotero_Master.docx'
module.main()
for name in ('NHIS_All_Adults_Manuscript','NHIS_All_Adults_Zotero_Master'):
    p=ROOT/'outputs/all_adults/manuscript'/f'{name}.docx'
    apply_caption_prefix_bold(p)
