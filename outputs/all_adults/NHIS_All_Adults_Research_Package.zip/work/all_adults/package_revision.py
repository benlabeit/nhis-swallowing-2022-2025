"""Package the completed revised adult analysis; never edits scientific inputs."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, csv, io, argparse

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--verified',action='store_true')
    args=parser.parse_args()
    if not args.verified: raise SystemExit('Run only after final scientific and document verification.')
    files={}
    def add(p):
        p=Path(p)
        if not p.is_absolute():p=ROOT/p
        assert p.is_file(),p
        assert p.resolve().is_relative_to(ROOT.resolve())
        files[p.relative_to(ROOT).as_posix()]=p
    for folder in ('outputs/all_adults','outputs/literature','outputs/data_original'):
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and p.suffix.lower() not in ('.zip','.pyc') and not p.name.startswith('~$'):
                add(p)
    for p in (ROOT/'work/all_adults').iterdir():
        if p.suffix in ('.py','.R','.json') and 'validation' not in p.stem.lower():add(p)
    for f in ('work/all_adults/README.md',
              'outputs/00_setup.R','outputs/01_prepare.R','outputs/NHIS_Manuscript_Final.docx',
              'outputs/author_checks.txt','outputs/author_information_provenance.txt',
              'outputs/Analyseplan.txt','outputs/analysis_plan_frozen.txt',
              'outputs/Analyseplan_Addendum.txt','outputs/source_sha256.tsv',
              'work/raw/adult22csv.zip','work/raw/adult25csv.zip',
              'work/dysphagia/format_manuscript.py','work/dysphagia/check_citations_anonymization.py',
              'work/dysphagia/format_master_bibliography_after_refresh.py',
              'work/dysphagia/zotero_dysphagia_bibliography.json',
              'work/dysphagia/zotero_dysphagia_citations.json',
              'work/dysphagia/nhis-dysphagia-basic-brackets.csl'):
        add(f)
    # Include survey descriptions; full codebooks are retrieved by the supplied
    # setup script from recorded CDC URLs to keep this handover below25MB.
    for yr in (2022,2025):add(f'work/docs/{yr}-srvydesc-508.pdf')
    manifest=list(csv.DictReader((ROOT/'outputs/data_original/original_data_manifest.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
    for row in manifest:
        base='work/raw' if row['file'].endswith('.zip') else 'outputs/data_original'
        p=ROOT/base/row['file']
        assert p.stat().st_size==int(row['bytes'])
        assert sha(p).lower()==row['sha256'].lower(),row['file']
    readme=(ROOT/'work/all_adults/README.md').read_bytes()
    contents={name:p.read_bytes() for name,p in sorted(files.items())}
    contents['README.md']=readme
    contents['requirements-R.txt']=b'survey\nnumDeriv\n'
    contents['requirements-python.txt']=b'python-docx\nlxml\nPillow\npypdf\n'
    buf=io.StringIO();w=csv.writer(buf,delimiter='\t',lineterminator='\n')
    w.writerow(['path','bytes','sha256'])
    for name,data in sorted(contents.items()):w.writerow([name,len(data),hashlib.sha256(data).hexdigest()])
    contents['revision_manifest.tsv']=buf.getvalue().encode()
    dest=OUT/'all_adults/NHIS_All_Adults_Research_Package.zip'
    with ZipFile(dest,'w',ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in contents.items():z.writestr(name,data)
    with ZipFile(dest) as z:assert z.testzip() is None
    info={'file':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest),'files':len(contents)}
    (ROOT/'work/all_adults/package_validation.json').write_text(json.dumps(info,indent=2))
    print(json.dumps(info,indent=2))

if __name__=='__main__':main()
