"""Create the revised all-adult journal manuscript from verified Zotero source.

Run only after the required artifact-operation marker and after replacing all
draft placeholders in manuscript_content.json. This builder does not overwrite
the historical older-adult files.
"""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile
import importlib.util
import json, re
from lxml import etree as E
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from manuscript_rewrite_helper import replace_prose_preserving_fields
from caption_prefix_bold import apply_caption_prefix_bold

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/all_adults'
OUT = ROOT / 'outputs/all_adults/manuscript'
SOURCE = ROOT / 'outputs/NHIS_Manuscript_Final.docx'
spec = importlib.util.spec_from_file_location('journal_format', ROOT / 'work/dysphagia/format_manuscript.py')
journal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(journal)
NS = journal.NS


def make_table(document, item):
    caption = document.add_paragraph(item['title'], style='Caption')
    caption.paragraph_format.keep_with_next = True
    caption.paragraph_format.space_before = Pt(8)
    caption.paragraph_format.space_after = Pt(5)
    ncols = len(item['columns'])
    table = document.add_table(rows=1, cols=ncols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    widths = item.get('widths_inches', [6.5/ncols]*ncols)
    assert len(widths) == ncols and sum(widths) <= 6.51
    for i, col in enumerate(table.columns):
        col.width = Inches(widths[i])
    for i, text in enumerate(item['columns']):
        table.rows[0].cells[i].text = str(text)
    for row_data in item['rows']:
        assert len(row_data) == ncols
        cells = table.add_row().cells
        for i, text in enumerate(row_data):
            cells[i].text = str(text)
    repeat = OxmlElement('w:tblHeader')
    table.rows[0]._tr.get_or_add_trPr().append(repeat)
    props = table._tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement('w:'+side)
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), '4')
        border.set(qn('w:color'), 'D9D9D9')
        borders.append(border)
    props.append(borders)
    for row_idx, row in enumerate(table.rows):
        # Do not split a compact row across pages; no fixed heights.
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for col_idx, cell in enumerate(row.cells):
            cell.width = Inches(widths[col_idx])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            margins = OxmlElement('w:tcMar')
            for side, val in [('top',70),('bottom',70),('left',65),('right',65)]:
                m = OxmlElement('w:'+side)
                m.set(qn('w:w'), str(val)); m.set(qn('w:type'), 'dxa')
                margins.append(m)
            tcpr.append(margins)
            if row_idx == 0:
                shade = OxmlElement('w:shd'); shade.set(qn('w:fill'), 'E7E6E6'); tcpr.append(shade)
            for p in cell.paragraphs:
                p.paragraph_format.line_spacing = 1
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.keep_with_next = False
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if col_idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    journal.font(run, item.get('font_size',9), row_idx == 0)
    note = document.add_paragraph(item['note'])
    note.paragraph_format.line_spacing = 1
    note.paragraph_format.space_after = Pt(8)
    for run in note.runs:
        journal.font(run, 9)


def make_figure(document, number, caption, image_dir):
    path = image_dir / f'Fig{number}.png'
    assert path.is_file(), path
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.line_spacing = 1
    shape = p.add_run().add_picture(str(path), width=Inches(6.5))
    shape._inline.docPr.set('descr', caption)
    shape._inline.docPr.set('title', f'Fig. {number}')
    p = document.add_paragraph(style='Caption')
    journal.font(p.add_run(f'Fig. {number} '), 10, True)
    p.add_run(caption)
    p.paragraph_format.keep_together = True
    p.paragraph_format.space_after = Pt(12)


def configure_bibliography(document):
    """Apply journal typography to the native bibliography style and paragraphs.

    Zotero identifiers, preferences, instructions and cached text are unchanged.
    Zotero Refresh may reapply its own style; inspect the refreshed document.
    """
    style = document.styles['Bibliography']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(11)
    style.font.color.rgb = RGBColor(0,0,0)
    style.paragraph_format.line_spacing = 1
    style.paragraph_format.keep_together = True
    style.paragraph_format.keep_with_next = False
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.find(qn('w:rFonts'))
    if fonts is None:
        fonts = OxmlElement('w:rFonts');rpr.insert(0, fonts)
    for attribute in list(fonts.attrib):
        if E.QName(attribute).localname.lower().endswith('theme'):
            del fonts.attrib[attribute]
    for attribute in ('ascii','hAnsi','eastAsia','cs'):
        fonts.set(qn('w:'+attribute),'Times New Roman')
    complex_size = rpr.find(qn('w:szCs'))
    if complex_size is None:
        complex_size = OxmlElement('w:szCs');rpr.append(complex_size)
    complex_size.set(qn('w:val'),'22')
    for paragraph in document.paragraphs:
        if paragraph.style.style_id == style.style_id:
            paragraph.paragraph_format.line_spacing = 1
            paragraph.paragraph_format.keep_together = True
            paragraph.paragraph_format.keep_with_next = False


def main():
    content = json.loads((WORK / 'manuscript_content.json').read_text(encoding='utf-8-sig'))
    assert not re.search(r'\[\[[A-Z]', json.dumps(content, ensure_ascii=False)), 'Unresolved draft placeholders'
    title = content['title']; abstract = content['abstract']
    assert len(abstract.split()) <= 250, len(abstract.split())
    tables = content['tables']; captions = content['captions']
    assert len(tables) == 3 and len(captions) == 4
    OUT.mkdir(parents=True, exist_ok=True)
    journal.TITLE = title; journal.KEYWORDS = content['keywords']
    base = Document(SOURCE); ps = base.paragraphs
    bibdata = json.loads((ROOT/'work/dysphagia/zotero_dysphagia_bibliography.json').read_text(encoding='utf-8-sig'))
    assert len(bibdata['bibliography']) == 25
    image_dir = ROOT / content.get('figure_directory', 'outputs/all_adults/figures')
    body_nodes = {}
    for i in range(16,53):
        body_nodes[i] = replace_prose_preserving_fields(ps[i]._p, content['paragraphs'][str(i)]) if str(i) in content['paragraphs'] else deepcopy(ps[i]._p)

    def build(identified):
        d = journal.blank_like(SOURCE)
        journal.para(d, title, 'Title')
        if identified:
            for i in range(2,11): journal.add_node(d, ps[i]._p)
        p = journal.para(d, 'Abstract', 'Heading 1')
        p.paragraph_format.page_break_before = identified
        journal.para(d, abstract)
        p = d.add_paragraph(); journal.font(p.add_run('Keywords '),11,True);p.add_run(content['keywords'])
        for i in range(16,53):
            journal.add_node(d, body_nodes[i])
            if i == 16: d.paragraphs[-1].paragraph_format.page_break_before = True
            if i == 31:
                journal.para(d, 'Generative AI assistance. ChatGPT (OpenAI) assisted with drafting analysis code, manuscript text and figure layouts, and with formatting. Statistical estimates were produced by the R scripts; numerical validation procedures are described above.')
            if i == 33: make_table(d, tables[0])
            if i == 35:
                make_table(d, tables[1]); make_figure(d, 1, captions['1'], image_dir)
            if i == 36: make_figure(d, 2, captions['2'], image_dir)
            if i == 39:
                make_table(d, tables[2]); make_figure(d, 3, captions['3'], image_dir)
                journal.para(d, content['age_specific_result'])
                make_figure(d, 4, captions['4'], image_dir)
        if content.get('supplementary_caption'):
            journal.para(d, 'Supplementary figure legend', 'Heading 1')
            journal.para(d, 'Fig. S1 '+content['supplementary_caption'], 'Caption')
        journal.data_availability(d, ps[54]._p)
        if identified:
            for i in range(55,68): journal.add_node(d, ps[i]._p)
        heading = journal.para(d, 'References', 'Heading 1')
        heading.paragraph_format.page_break_before = True
        heading.paragraph_format.keep_with_next = True
        for i, entry in enumerate(bibdata['bibliography']):
            node = deepcopy(ps[69+i]._p)
            journal.replace_cached(node, entry['text'] if isinstance(entry,dict) else entry)
            journal.add_node(d, node)
        for run in ps[94]._p:
            if run.tag == qn('w:r') and any(f.get(qn('w:fldCharType'))=='end' for f in run.findall(qn('w:fldChar'))):
                d.paragraphs[-1]._p.append(deepcopy(run))
        journal.configure(d)
        d.styles['Caption'].font.bold = False
        configure_bibliography(d)
        if not identified:
            d.core_properties.author = '';d.core_properties.last_modified_by='';d.core_properties.comments='';d.core_properties.identifier=''
        name = 'NHIS_All_Adults_Zotero_Master.docx' if identified else 'NHIS_All_Adults_Manuscript.docx'
        path = OUT / name
        d.save(path)
        journal.postprocess(path, flat=not identified, reference_data=bibdata)
        apply_caption_prefix_bold(path)
        (OUT/path.with_suffix('.txt').name).write_text('\n\n'.join(p.text for p in Document(path).paragraphs), encoding='utf-8')
        return path

    paths = [build(False), build(True)]
    auth = journal.blank_like(SOURCE)
    journal.para(auth, title, 'Title')
    for i in range(2,11): journal.add_node(auth, ps[i]._p)
    for i in range(55,68): journal.add_node(auth, ps[i]._p)
    journal.data_availability(auth)
    journal.configure(auth)
    author_path = OUT/'NHIS_All_Adults_Author_Information.docx'
    auth.save(author_path);journal.postprocess(author_path, flat=True);paths.append(author_path)
    stats={'title':title, 'abstract_words':len(abstract.split()), 'references':25, 'tables':3,'figures':4,'files':{}}
    for path in paths:
        with ZipFile(path) as z:
            root = E.fromstring(z.read('word/document.xml'))
            codes = root.xpath('.//w:instrText/text()',namespaces=NS)
            delimiters={kind:len(root.xpath('.//w:fldChar[@w:fldCharType="'+kind+'"]',namespaces=NS)) for kind in ('begin','separate','end')}
            assert len(set(delimiters.values()))==1,delimiters
            stats['files'][path.name]={'citation_fields':sum('ZOTERO_ITEM' in code for code in codes),'bibliography_fields':sum('ZOTERO_BIBL ' in code for code in codes),'field_delimiters':delimiters,'tables':len(Document(path).tables)}
    assert stats['files'][paths[0].name]['citation_fields']==0
    assert stats['files'][paths[1].name]['citation_fields']==19
    assert stats['files'][paths[1].name]['bibliography_fields']==1
    for path in paths[:2]:
        text = '\n'.join(p.text for p in Document(path).paragraphs)
        assert '[[' not in text
        assert 'Swallowing Difficulties in Older US Adults' not in text
    (WORK/'document_build_validation.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
    print(json.dumps(stats,indent=2))


if __name__ == '__main__':
    main()
