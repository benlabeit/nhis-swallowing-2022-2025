"""Apply the established read-only 25-item citation/privacy audit to this revision."""
from pathlib import Path
root=Path(__file__).resolve().parents[2]
source=(root/'work/dysphagia/check_citations_anonymization.py').read_text(encoding='utf-8')
source=source.replace("'outputs/dysphagia'", "'outputs/all_adults/manuscript'")
source=source.replace('NHIS_Dysphagia_', 'NHIS_All_Adults_')
source=source.replace('work/dysphagia/citation_anonymization_check.txt',
                      'outputs/all_adults/manuscript/Citation_Anonymization_Validation.txt')
exec(compile(source,__file__,'exec'))
