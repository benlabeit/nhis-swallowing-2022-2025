"""Replace body prose while retaining existing Zotero fields and paragraph formatting.

This is authoring infrastructure only. Importing this module does not edit a DOCX.
The source index map refers to outputs/NHIS_Manuscript_Final.docx, the source
used by work/dysphagia/format_manuscript.py, NOT the journal-layout master.
"""
from copy import deepcopy
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


def replace_prose_preserving_fields(paragraph_element, prose):
    """Return a copy with new prose, preserving a final complex citation field.

    Source citations are at the end of their paragraphs. Fields may have split
    instructions or an end delimiter in a cached-text run; retain whole runs
    from the first begin delimiter onward. If there is a field, the caller
    must not include a manually typed citation in prose.
    """
    node = deepcopy(paragraph_element)
    children = list(node)
    starts = [i for i, child in enumerate(children)
              if child.tag == qn('w:r') and any(
                  f.get(qn('w:fldCharType')) == 'begin'
                  for f in child.findall(qn('w:fldChar')))]
    first_field = starts[0] if starts else len(children)
    for child in children[:first_field]:
        if child.tag != qn('w:pPr'):
            node.remove(child)
    run = OxmlElement('w:r')
    text = OxmlElement('w:t')
    text.set(qn('xml:space'), 'preserve')
    text.text = prose.rstrip() + ('\u00a0' if starts else '')
    run.append(text)
    node.insert(1 if len(node) and node[0].tag == qn('w:pPr') else 0, run)
    return node


SOURCE_INDEX_MAP = {
    'intro_population': 17, 'intro_measurement': 18, 'intro_stroke': 19,
    'objectives': 20, 'design': 22, 'comparability': 23, 'outcomes': 24,
    'planning_missingness': 25, 'survey_standardization': 26,
    'contrasts': 27, 'quality': 28, 'quarter_sensitivity': 29,
    'sex_adjustment': 30, 'response_sensitivity': 31,
    'sample': 33, 'overall_result': 34, 'stroke_result': 35,
    'secondary_result': 36, 'period_missing_result': 37,
    'sex_adjusted_result': 38, 'self_response_result': 39,
    'principal_findings': 41, 'historical_context': 42,
    'measurement_context': 43, 'stroke_interpretation': 44,
    'response_interpretation': 45, 'clinical_context': 46,
    'care_access': 47, 'limitations': 48, 'comparability_limits': 49,
    'strengths_future': 50, 'conclusion': 52,
}

RESULT_DEPENDENT_INDICES = [33, 34, 35, 36, 37, 38, 39, 41, 45, 49, 52]
